import configparser
import os
import sys
from functools import partial
from pathlib import Path
from typing import Optional

from qgis.core import QgsApplication, QgsProject, QgsSettings
from qgis.gui import QgisInterface, QgsMapTool
from qgis.PyQt.QtCore import QSize, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QActionGroup,
    QDialog,
    QMenu,
    QMessageBox,
    QToolBar,
    QToolButton,
)

from .packages import add_egrn
from .packages.egrn_tools_settings import EgrnToolsSettings
from .packages.IdentificationTool import IdentificationTool
from .packages.pkk_data_item_provider import PkkLayersDataItemProvider
from .packages.search_panel import NGQRosreestrToolsSearchPanel

HAS_NGSTD = True
try:
    from ngstd import ximport
    from ngstd._framework import NGAccess

except ImportError:
    HAS_NGSTD = False

from .packages import about_dialog
from .packages import ng_network


class NGQRosreestrTools:
    """QGIS Plugin Implementation."""

    iface: QgisInterface
    menu_name: str
    __toolbar: QToolBar
    __import_egrn_action: QAction
    __search_panel_action: QAction
    __add_egrn_tool_button: QToolButton
    __identify_egrn_tool_button: QToolButton
    __search_panel: Optional[NGQRosreestrToolsSearchPanel]
    __identify_tool: Optional[IdentificationTool]
    __tool_was_activated: bool
    __import_dialog: Optional[QDialog]
    __item_provider: Optional[PkkLayersDataItemProvider]

    def __init__(self, iface) -> None:
        """Initialize plugin variables"""
        self.iface = iface
        self.menu_name = "&NGQ Rosreestr Tools"
        self.__toolbar = None
        self.api_key = None
        self.api_error = None
        self.__import_egrn_action = None
        self.__search_panel_action = None
        self.__add_egrn_tool_button = None
        self.__identify_egrn_tool_button = None
        self.__search_panel = None
        self.__identify_tool = None
        self.__import_dialog = None
        self.__tool_was_activated = False
        self.__item_provider = False

    def initGui(self) -> None:  # pylint: disable=invalid-name
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        self.__fetch_api_key()

        if HAS_NGSTD:
            # Update API key
            NGAccess.instance().supportInfoUpdated.connect(
                self.__update_api_key
            )

        self.__init_menus()
        self.__init_item_provider()

    def unload(self) -> None:
        """Remove plugin widgets from QGIS GUI."""
        if HAS_NGSTD:
            NGAccess.instance().supportInfoUpdated.disconnect(
                self.__update_api_key
            )

        self.__unload_import_dialog()
        self.__unload_tool()
        self.__unload_search_panel()
        self.__unload_item_provider()
        self.__unload_menus()

    def __show_import_egrn_dialog(self) -> None:
        if not self.__is_user_ok():
            NGAccess.showUnsupportedMessage(None)
            return

        protected_package_path = os.path.join(
            os.path.dirname(__file__), "protected_package.ngsrc"
        )

        if os.path.exists(protected_package_path):
            # Not protected
            sys.path.insert(0, protected_package_path)
        else:
            # Protected
            cfg = configparser.ConfigParser()
            cfg.read(os.path.join(os.path.dirname(__file__), "metadata.txt"))
            plugin_version = cfg.get("general", "version")

            plugin_password = (
                NGAccess.instance()
                .getPluginSign("NGQ Rosreestr Tools", plugin_version)
                .encode()
            )

            if not plugin_password:
                NGAccess.showUnsupportedMessage(None)
                return

            zip_path = os.path.join(
                os.path.dirname(__file__), "protected_package.ngpp"
            )

            importer = ximport.ximporter(zip_path, plugin_password)
            sys.meta_path.insert(0, importer)

        if self.__import_dialog is None:
            from .packages.import_egrn import NGQRosreestrToolsImportEGRN

            self.__import_dialog = NGQRosreestrToolsImportEGRN()

        self.__import_dialog.reset()
        self.__import_dialog.show()

    def __add_egrn_layer(self, ctype) -> None:
        if not self.__is_user_ok():
            NGAccess.showUnsupportedMessage(None)
            return

        if self.api_key is None:
            QMessageBox.information(
                self.iface.mainWindow(),
                "Внимание!",
                "Невозможно получить ключ API для инструментов Росреестра",
            )
            return

        layer = add_egrn.get_egrn_layer(ctype=ctype, api_key=self.api_key)
        if layer["status"] != "ok":
            QMessageBox.information(
                self.iface.mainWindow(),
                "Внимание!",
                f'Невозможно добавить слой. Причина: {layer["message"]}',
            )
            return

        QgsProject.instance().addMapLayer(layer["layer"])

    def __activate_identification(self, identififcation_type: str) -> None:
        if not self.__is_user_ok():
            NGAccess.showUnsupportedMessage(None)
            return

        if self.api_key is None:
            QMessageBox.information(
                self.iface.mainWindow(),
                "Внимание!",
                "Невозможно получить ключ API для инструментов Росреестра",
            )
            return

        self.__save_tool_button_state(identififcation_type)

        if self.__identify_tool is None:
            self.__init_tool()

        self.__identify_tool.set_type(identififcation_type)
        self.iface.mapCanvas().setMapTool(self.__identify_tool)

    def __toggle_search_panel_visibility(self) -> None:
        if not self.__is_user_ok():
            NGAccess.showUnsupportedMessage(None)
            return

        if self.api_key is None:
            QMessageBox.information(
                self.iface.mainWindow(),
                "Внимание!",
                "Невозможно получить ключ API для инструментов Росреестра",
            )
            return

        if self.__search_panel is None:
            self.__init_search_panel()
        else:
            self.__search_panel.toggleUserVisible()

    def __icon(self, icon_name: str) -> QIcon:
        current_path = os.path.abspath(os.path.dirname(__file__))
        icons_path = os.path.abspath(
            os.path.join(current_path, "resources", "icons")
        )
        return QIcon(os.path.abspath(os.path.join(icons_path, icon_name)))

    def __init_menus(self) -> None:
        self.__toolbar = self.iface.addToolBar("NGQRosreestrTools")
        self.__toolbar.setObjectName("NGQRosreestrTools")

        self.__init_import_menu()
        self.__init_add_layer_menus()
        self.__init_identify_menus()
        self.__init_search_menus()
        self.__init_about_dialog()

        self.__update_icons()

        if HAS_NGSTD:
            NGAccess.instance().supportInfoUpdated.connect(self.__update_icons)

    def __init_import_menu(self) -> None:
        # Import EGRN
        import_egrn_title = "Импорт данных ЕГРН"
        self.__import_egrn_action = QAction(
            icon=self.__icon("RR-addVector.svg"),
            text=import_egrn_title,
        )
        self.__import_egrn_action.triggered.connect(
            self.__show_import_egrn_dialog
        )
        self.__import_egrn_action.setEnabled(self.__is_usable())
        self.__import_egrn_action.setWhatsThis(import_egrn_title)

        self.__toolbar.addAction(self.__import_egrn_action)
        self.iface.addPluginToVectorMenu(
            self.menu_name, self.__import_egrn_action
        )

    def __init_add_layer_menus(self) -> None:
        """Init rosreestr layers menu"""

        # Common icon
        add_egrn_icon = self.__icon("RR-addRaster.svg")

        # Слой кадастровых кварталов
        add_kvartaly_title = "Добавить слой кадастровых кварталов, округа"
        add_egrn_kvartaly_action = QAction(
            icon=add_egrn_icon,
            text=add_kvartaly_title,
        )
        add_egrn_kvartaly_action.triggered.connect(
            partial(self.__add_egrn_layer, "kvartaly")
        )
        add_egrn_kvartaly_action.setEnabled(self.__is_usable())
        add_egrn_kvartaly_action.setWhatsThis(add_kvartaly_title)

        # Слой змельных участков
        add_uchastki_title = "Добавить слой земельных участков, ОКС"
        add_egrn_uchastki_action = QAction(
            icon=add_egrn_icon,
            text=add_uchastki_title,
        )
        add_egrn_uchastki_action.triggered.connect(
            partial(self.__add_egrn_layer, "uchastki")
        )
        add_egrn_uchastki_action.setEnabled(self.__is_usable())
        add_egrn_uchastki_action.setWhatsThis(add_uchastki_title)

        # Зоны с особыми условиями
        add_zony_title = "Добавить слой зон с особыми условиями использования"
        add_egrn_zony_action = QAction(
            icon=add_egrn_icon,
            text=add_zony_title,
        )
        add_egrn_zony_action.triggered.connect(
            partial(self.__add_egrn_layer, "zony")
        )
        add_egrn_zony_action.setEnabled(self.__is_usable())
        add_egrn_zony_action.setWhatsThis(add_zony_title)

        # Create menu
        add_egrn_popup_menu = QMenu()
        add_egrn_popup_menu.addAction(add_egrn_kvartaly_action)
        add_egrn_popup_menu.addAction(add_egrn_uchastki_action)
        add_egrn_popup_menu.addAction(add_egrn_zony_action)
        add_egrn_kvartaly_action.setParent(add_egrn_popup_menu)
        add_egrn_uchastki_action.setParent(add_egrn_popup_menu)
        add_egrn_zony_action.setParent(add_egrn_popup_menu)

        # Create toolbutton
        self.__add_egrn_tool_button = QToolButton()
        self.__add_egrn_tool_button.setMenu(add_egrn_popup_menu)
        self.__add_egrn_tool_button.setDefaultAction(add_egrn_kvartaly_action)
        self.__add_egrn_tool_button.setPopupMode(QToolButton.InstantPopup)
        self.__add_egrn_tool_button.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonIconOnly
        )

        self.__toolbar.addWidget(self.__add_egrn_tool_button)

    def __init_identify_menus(self) -> None:
        self.__identify_egrn_tool_button = QToolButton()
        self.__identify_egrn_tool_button.setPopupMode(
            QToolButton.ToolButtonPopupMode.MenuButtonPopup
        )
        self.__identify_egrn_tool_button.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonIconOnly
        )
        self.__toolbar.addWidget(self.__identify_egrn_tool_button)

        # Идентификация земельных участков
        identify_uchastki_title = "Идентификация земельных участков"
        identify_egrn_uchastki_action = QAction(
            icon=self.__icon("RR-identification-land.svg"),
            text=identify_uchastki_title,
            parent=self.__identify_egrn_tool_button,
        )
        identify_egrn_uchastki_action.setCheckable(True)
        identify_egrn_uchastki_action.triggered.connect(
            partial(self.__activate_identification, "uchastki")
        )
        identify_egrn_uchastki_action.setEnabled(self.__is_usable())
        identify_egrn_uchastki_action.setWhatsThis(identify_uchastki_title)
        self.__identify_egrn_tool_button.addAction(
            identify_egrn_uchastki_action
        )

        # Идентификация объектов капитального строительства
        identify_oks_title = (
            "Идентификация объектов капитального строительства"
        )
        identify_egrn_oks_action = QAction(
            icon=self.__icon("RR-identification-oks.svg"),
            text=identify_oks_title,
            parent=self.__identify_egrn_tool_button,
        )
        identify_egrn_oks_action.setCheckable(True)
        identify_egrn_oks_action.triggered.connect(
            partial(self.__activate_identification, "oks")
        )
        identify_egrn_oks_action.setEnabled(self.__is_usable())
        self.__identify_egrn_tool_button.addAction(identify_egrn_oks_action)

        # Идентификация кадастровых кварталов
        identify_kvartal_title = "Идентификация кадастровых кварталов"
        identify_egrn_kvartaly_action = QAction(
            icon=self.__icon("RR-identification-quarter.svg"),
            text=identify_kvartal_title,
            parent=self.__identify_egrn_tool_button,
        )
        identify_egrn_kvartaly_action.setCheckable(True)
        identify_egrn_kvartaly_action.triggered.connect(
            partial(self.__activate_identification, "kvartaly")
        )
        identify_egrn_kvartaly_action.setEnabled(self.__is_usable())
        identify_egrn_kvartaly_action.setWhatsThis(identify_kvartal_title)
        self.__identify_egrn_tool_button.addAction(
            identify_egrn_kvartaly_action
        )

        # Идентификация зон с особыми условиями использования территории
        identify_zouit_title = (
            "Идентификация зон с особыми условиями использования территории"
        )
        identify_egrn_zouit_action = QAction(
            icon=self.__icon("RR-identification-zones.svg"),
            text=identify_zouit_title,
            parent=self.__identify_egrn_tool_button,
        )
        identify_egrn_zouit_action.setCheckable(True)
        identify_egrn_zouit_action.triggered.connect(
            partial(self.__activate_identification, "zouit")
        )
        identify_egrn_zouit_action.setEnabled(self.__is_usable())
        identify_egrn_zouit_action.setWhatsThis(identify_zouit_title)
        self.__identify_egrn_tool_button.addAction(identify_egrn_zouit_action)

        # Закомментировал по задаче https://app.clickup.com/t/865c2mmj2
        # # Идентификация кадастровых округов
        # identify_area_title = 'Идентификация кадастровых округов'
        # identify_egrn_area_action = QAction(
        #     icon=identification_icon,
        #     text=identify_area_title,
        # )
        # identify_egrn_area_action.triggered.connect(
        #     partial(self.__activate_identification, 'area')
        # )
        # identify_egrn_area_action.setEnabled(self.__is_usable())
        # identify_egrn_area_action.setWhatsThis(identify_area_title)

        group = QActionGroup(self.__identify_egrn_tool_button)
        group.setExclusive(True)
        group.addAction(identify_egrn_uchastki_action)
        group.addAction(identify_egrn_oks_action)
        group.addAction(identify_egrn_kvartaly_action)
        group.addAction(identify_egrn_zouit_action)

        last_used_tool = QgsSettings().value(
            "NextGIS/RosreestrTools/lastIdentificationTool", 0, type=int
        )
        self.__identify_egrn_tool_button.setDefaultAction(
            group.actions()[last_used_tool]
        )

    def __init_search_menus(self) -> None:
        """Init search menu"""
        search_title = "Показать/скрыть панель поиска"
        self.__search_panel_action = QAction(
            icon=self.__icon("RR-search.svg"),
            text=search_title,
        )
        self.__search_panel_action.triggered.connect(
            self.__toggle_search_panel_visibility
        )
        self.__search_panel_action.setEnabled(self.__is_usable())
        self.__search_panel_action.setWhatsThis(search_title)

        self.__toolbar.addAction(self.__search_panel_action)
        self.iface.addPluginToVectorMenu(
            self.menu_name, self.__search_panel_action
        )

    def __init_about_dialog(self) -> None:
        """Init about menu"""
        about_title = "О модуле…"
        self.__about_panel_action = QAction(
            icon=self.__icon("about.png"),
            text=about_title,
        )
        self.__about_dialog = about_dialog.AboutDialog(
            os.path.basename(str(Path(__file__).parent))
        )

        self.__about_panel_action.triggered.connect(self.show_about_dialog)

        self.__about_panel_action.setEnabled(self.__is_usable())
        self.__about_panel_action.setWhatsThis(about_title)
        self.iface.addPluginToVectorMenu(
            self.menu_name, self.__about_panel_action
        )

        self.__help_action = QAction(
            icon=self.__icon("icon.svg"),
            text=self.menu_name.replace("&", ""),
        )
        self.__help_action.triggered.connect(self.show_about_dialog)

        plugin_help_menu = self.iface.pluginHelpMenu()
        assert plugin_help_menu is not None
        plugin_help_menu.addAction(self.__help_action)

    def show_about_dialog(self) -> None:
        self.__about_dialog.exec()

    def __unload_menus(self):
        """Unload all added actions"""

        # Remove connection to update icons
        if HAS_NGSTD:
            NGAccess.instance().supportInfoUpdated.disconnect(
                self.__update_icons
            )

        # Remove from vector menu
        self.iface.removePluginVectorMenu(
            self.menu_name, self.__import_egrn_action
        )
        self.iface.removePluginVectorMenu(
            self.menu_name, self.__search_panel_action
        )

        # Remove toolbar
        # __add_egrn_tool_button, __identify_egrn_tool_button will be deleted
        # also because addWidget transfers ownership
        self.__toolbar.deleteLater()

        # Remove actions
        self.__add_egrn_tool_button.menu().deleteLater()
        self.__import_egrn_action.deleteLater()
        self.__search_panel_action.deleteLater()

    def __init_item_provider(self) -> None:
        self.__item_provider = PkkLayersDataItemProvider()
        QgsApplication.instance().dataItemProviderRegistry().addProvider(
            self.__item_provider
        )

    def __unload_item_provider(self) -> None:
        QgsApplication.instance().dataItemProviderRegistry().removeProvider(
            self.__item_provider
        )
        self.__item_provider = None

    def __unload_import_dialog(self) -> None:
        if self.__import_dialog is not None:
            self.__import_dialog.deleteLater()
            self.__import_dialog = None

        # Нужно создать подкаталог и его очищать, чтобы работала перезагрузка
        # Должно решиться при использовании библиотеки
        # if 'import_egrn' in sys.modules:
        #     protected_package_path = os.path.join(
        #         os.path.dirname(__file__), 'protected_package.ngsrc'
        #     )
        #     if protected_package_path in sys.path:
        #         try:
        #             sys.path.remove(protected_package_path)
        #         except ValueError:
        #             # Discard if path is not there
        #             pass
        #     # TODO remove zip path
        #     try:
        #         del sys.modules['import_egrn']
        #     except:
        #         # TODO log
        #         pass

    def __init_search_panel(self) -> None:
        # Create the dockwidget (after translation) and keep reference

        if not self.__is_user_ok():
            return

        if self.api_key is None:
            return

        self.__search_panel = NGQRosreestrToolsSearchPanel(
            api_key=self.api_key
        )
        self.__search_panel_action.setCheckable(True)
        self.__search_panel.visibilityChanged.connect(
            self.__search_panel_action.setChecked
        )

        self.iface.addTabifiedDockWidget(
            Qt.DockWidgetArea.LeftDockWidgetArea, self.__search_panel
        )
        self.__search_panel.setUserVisible(True)

    def __unload_search_panel(self) -> None:
        if self.__search_panel is None:
            return

        self.__search_panel_action.setCheckable(False)

        self.__search_panel.setUserVisible(False)
        self.iface.removeDockWidget(self.__search_panel)
        self.__search_panel.deleteLater()
        self.__search_panel = None

    def __init_tool(self) -> None:
        self.__identify_tool = IdentificationTool(self.iface, "", self.api_key)
        self.iface.mapCanvas().mapToolSet.connect(self.__on_map_tool_changed)

    def __unload_tool(self) -> None:
        if self.__identify_tool is None:
            return

        if self.iface.mapCanvas().mapTool() == self.__identify_tool:
            self.iface.mapCanvas().unsetMapTool(self.__identify_tool)

        self.iface.mapCanvas().mapToolSet.disconnect(
            self.__on_map_tool_changed
        )

        self.__identify_tool.deleteLater()
        self.__identify_tool = None

    def __update_icons(self) -> None:
        def lock_icon(icon: QIcon) -> QIcon:
            return NGAccess.lockIcon(icon, QSize(24, 24), QIcon())

        import_egrn_icon = self.__icon("RR-addVector.svg")
        add_egrn_icon = self.__icon("RR-addRaster.svg")
        identification_icons = [
            self.__icon("RR-identification-land.svg"),
            self.__icon("RR-identification-oks.svg"),
            self.__icon("RR-identification-quarter.svg"),
            self.__icon("RR-identification-zones.svg"),
        ]
        search_panel_icon = self.__icon("RR-search.svg")

        if HAS_NGSTD and not self.__is_user_ok():
            import_egrn_icon = lock_icon(import_egrn_icon)
            add_egrn_icon = lock_icon(add_egrn_icon)
            for i, _icon in enumerate(identification_icons):
                identification_icons[i] = lock_icon(identification_icons[i])
            search_panel_icon = lock_icon(search_panel_icon)

        self.__import_egrn_action.setIcon(import_egrn_icon)
        for action in self.__add_egrn_tool_button.menu().actions():
            action.setIcon(add_egrn_icon)
        identify_actions = self.__identify_egrn_tool_button.actions()
        for i, action in enumerate(identify_actions):
            action.setIcon(identification_icons[i])
        self.__search_panel_action.setIcon(search_panel_icon)

    def __fetch_api_key(self) -> None:
        # API Key
        self.api_key = None
        self.api_error = ""
        api_key_request = ng_network.get_api_key()
        if api_key_request["status"] == "ok":
            self.api_key = api_key_request["api_key"]
        else:
            self.api_error = (
                "Невозможно получить API Key для инструментов"
                + f' Росреестра. Ошибка: {api_key_request["message"]}'
            )

    def __update_api_key(self) -> None:
        self.__fetch_api_key()

        # TODO (ivanbarsukov): make setters for api_key

        self.__unload_import_dialog()
        self.__unload_search_panel()
        self.__unload_tool()

    def __on_map_tool_changed(self, tool: QgsMapTool) -> None:
        if tool == self.__identify_tool:
            self.__tool_was_activated = True
        elif self.__tool_was_activated:
            self.__identify_egrn_tool_button.setChecked(False)
            self.__tool_was_activated = False

    def __save_tool_button_state(self, identification_type: str = "") -> None:
        indices = {
            "uchastki": 0,
            "oks": 1,
            "kvartaly": 2,
            "zouit": 3,
        }

        if (index := indices.get(identification_type)) is None:
            return

        actions = self.__identify_egrn_tool_button.actions()
        action = actions[index]
        self.__identify_egrn_tool_button.setDefaultAction(action)
        action.setChecked(True)

        QgsSettings().setValue(
            "NextGIS/RosreestrTools/lastIdentificationTool", value=index
        )

    def __is_usable(self) -> bool:
        if EgrnToolsSettings().is_developer_mode:
            return True

        return HAS_NGSTD

    def __is_user_ok(self) -> bool:
        if EgrnToolsSettings().is_developer_mode:
            return True

        return (
            NGAccess.instance().isUserAuthorized()
            and NGAccess.instance().isUserSupported()
        )
