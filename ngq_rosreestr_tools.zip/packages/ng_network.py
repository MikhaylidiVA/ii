import json
import os
from base64 import b64encode

try:
    from ngstd._core import NGRequest  # type: ignore

    HAS_NGSTD = True
except ImportError:
    NGRequest = None

    HAS_NGSTD = False


from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtCore import (
    QByteArray,
    QEventLoop,
    QUrl,
)
from qgis.PyQt.QtNetwork import QNetworkRequest

from .egrn_tools_settings import EgrnToolsSettings

endpoints_path = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__), os.pardir, "resources", "endpoints.json"
    )
)

endpoints = None
with open(endpoints_path) as endpoints_file:
    endpoints = json.load(endpoints_file)


def simple_get(url, user, password):
    authstr = b"Basic " + b64encode(f"{user}:{password}".encode())
    authstr = QByteArray(authstr)
    req = QNetworkRequest(QUrl(url))

    if user != "":
        req.setRawHeader(b"Authorization", authstr)

    r = QgsNetworkAccessManager.instance().get(req)
    loop = QEventLoop()
    r.finished.connect(loop.quit)
    loop.exec_()
    r.finished.disconnect(loop.quit)
    status_code = r.attribute(QNetworkRequest.HttpStatusCodeAttribute)
    bytes_string = r.readAll()

    return {
        "status": "ok",
        "status_code": status_code,
        "content": bytes_string,
    }


def get_with_token(url, token):
    req = QNetworkRequest(QUrl(url))
    req.setRawHeader(b"Authorization", token.encode())
    networkAccessManager = QgsNetworkAccessManager.instance()
    r = networkAccessManager.get(req)
    loop = QEventLoop()
    r.finished.connect(loop.quit)
    loop.exec_()
    r.finished.disconnect(loop.quit)
    status_code = r.attribute(QNetworkRequest.HttpStatusCodeAttribute)
    bytes_string = r.readAll()
    return {
        "status": "ok",
        "status_code": status_code,
        "content": bytes_string,
    }


def post_with_token(url, token, data=None, file=None):
    reply = QNetworkRequest(QUrl(url))
    reply.setRawHeader(b"Authorization", token.encode())

    networkAccessManager = QgsNetworkAccessManager.instance()

    if data is not None:
        reply = networkAccessManager.post(reply, json.dumps(data).encode())

    if file is not None:
        reply = networkAccessManager.post(reply, file.read())

    loop = QEventLoop()
    reply.finished.connect(loop.quit)
    loop.exec_()
    reply.finished.disconnect(loop.quit)
    status_code = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute)
    bytes_string = reply.readAll()

    return status_code, bytes_string


def get_my_nextgis_auth_header():
    assert isinstance(endpoints, dict)
    auth_header = NGRequest.getAuthHeader(endpoints["ng_api_key_source"])
    return auth_header.replace("Authorization: ", "")


def get_api_key():
    if EgrnToolsSettings().is_developer_mode:
        return {"status": "ok", "api_key": ""}

    auth_header = get_my_nextgis_auth_header()
    if not auth_header:
        return {
            "status": "error",
            "message": "Невозможно получить заголовок авторизации",
        }

    assert isinstance(endpoints, dict)
    user_config = get_with_token(endpoints["ng_api_key_source"], auth_header)

    if user_config["status"] == "ok":
        try:
            data = json.loads(
                str(user_config["content"].data(), encoding="utf-8")
            )
            api_key = data["api_key"]
        except Exception as e:
            return {
                "status": "error",
                "message": f"Невозможно получить ключ авторизации. Ошибка: {str(e)}",
            }

        return {"status": "ok", "api_key": api_key}
    return {
        "status": "error",
        "message": "Невозможно получить ключ авторизации. Ошибка: {}".format(
            user_config["message"]
        ),
    }


def get_pkk_feature(
    lat: str, lon: str, object_type: str, api_key: str
) -> None:
    num_type = 1
    if object_type == "kvartaly":
        num_type = 2
    if object_type == "uchastki":
        num_type = 1
    if object_type == "area":
        num_type = 4
    if object_type == "oks":
        num_type = 5

    assert isinstance(endpoints, dict)
    url = (
        endpoints["ng_pkk_features_by_position_source"]
        + f"?apikey={api_key}&lat={lat}&lon={lon}&cache=include&types={num_type}"
    )

    simple_get(url, "", "")
