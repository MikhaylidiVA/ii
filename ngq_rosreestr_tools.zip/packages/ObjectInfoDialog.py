import platform
from typing import List, Optional, cast

from qgis.core import QgsVectorLayer
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QClipboard, QMouseEvent
from qgis.PyQt.QtWidgets import (
    QAction,
    QApplication,
    QLabel,
    QMenu,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qgis.utils import iface

from . import utils
from .pkk_feature_parser import PkkFeature


class TableWidget(QTableWidget):
    def mouseReleaseEvent(self, e: Optional[QMouseEvent]) -> None:
        if e is not None and e.button() == Qt.MouseButton.BackButton:
            cast(QWidget, self.parent()).mouseReleaseEvent(e)
            return
        super().mouseReleaseEvent(e)


class ObjectInfoDialog(QWidget):
    def __init__(self, title, parent=None) -> None:
        super().__init__(parent)

        layout = QVBoxLayout()

        self.setLayout(layout)
        layout.setContentsMargins(0, 0, 0, 0)

        self.__nogeomLabel = QLabel(self)
        self.__nogeomLabel.setText("Без координат границ")
        self.__nogeomLabel.setMargin(3)
        self.__nogeomLabel.setStyleSheet(
            """
            QLabel {
                border-radius: 3%;
                background-color : #f3ab10;
                color : white;
            }
            """
        )
        self.__nogeomLabel.setAutoFillBackground(True)
        # self.__nogeomLabel.hide()

        self.__featureSubtitleLabel = QLabel(self)
        self.__featureSubtitleLabel.setWordWrap(True)
        self.__featureSubtitleLabel.hide()
        self.__featureInfoLabel = QLabel(self)
        self.__featureInfoLabel.setWordWrap(True)
        self.__featureInfoLabel.hide()

        self.__resultsTable = TableWidget(self)
        vertical_header = self.__resultsTable.verticalHeader()
        assert vertical_header is not None
        vertical_header.hide()
        self.__resultsTable.setAlternatingRowColors(True)
        self.__resultsTable.setMinimumSize(350, 250)
        self.__resultsTable.setColumnCount(2)
        self.__resultsTable.setRowCount(0)
        self.__resultsTable.setColumnWidth(0, 180)
        horizontal_header = self.__resultsTable.horizontalHeader()
        assert horizontal_header is not None
        horizontal_header.setStretchLastSection(True)

        self.__resultsTable.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self.__resultsTable.customContextMenuRequested.connect(self.openMenu)

        self.__resultsTable.setHorizontalHeaderLabels(["Параметр", "Значение"])

        layout.addWidget(self.__nogeomLabel)
        layout.addWidget(self.__featureSubtitleLabel)
        layout.addWidget(self.__featureInfoLabel)
        layout.addWidget(self.__resultsTable)

        self.__feature = None

    def openMenu(self, position) -> None:
        selected_items = self.__resultsTable.selectedItems()

        if len(selected_items) > 0:
            menu = QMenu()

            actionCopyAttr = QAction("Скопировать атрибут", self)
            menu.addAction(actionCopyAttr)
            actionCopyAttr.setStatusTip("Скопировать атрибут")
            actionCopyAttr.triggered.connect(self.copy_attr)

            actionCopyRecord = QAction("Скопировать запись", self)
            menu.addAction(actionCopyRecord)
            actionCopyRecord.setStatusTip("Скопировать запись")
            actionCopyRecord.triggered.connect(self.copy_record)

            actionCopyAll = QAction("Скопировать всё", self)
            menu.addAction(actionCopyAll)
            actionCopyAll.setStatusTip("Скопировать всё")
            actionCopyAll.triggered.connect(self.copy_all)

            menu.addSeparator()

            actionCreateLayer = QAction("Добавить объект в новый слой", self)
            menu.addAction(actionCreateLayer)
            actionCreateLayer.setStatusTip("Добавить объект в новый слой")
            actionCreateLayer.triggered.connect(self.create_layer)

            actionAddFeature = QAction("Добавить объект в активный слой", self)
            menu.addAction(actionAddFeature)
            actionAddFeature.setStatusTip("Добавить объект в активный слой")
            actionAddFeature.triggered.connect(self.add_feature)
            active_layer = iface.mapCanvas().currentLayer()
            if not isinstance(active_layer, QgsVectorLayer):
                actionAddFeature.setDisabled(True)

            viewport = self.__resultsTable.viewport()
            assert viewport is not None

            menu.exec_(viewport.mapToGlobal(position))

    def create_layer(self) -> None:
        if self.__feature is None:
            return

        utils.add_to_new_layer(self.__feature)

    def add_feature(self) -> None:
        if self.__feature is None:
            return

        utils.add_to_active_layer(self.__feature)

    def copy_attr(self) -> None:
        selected_index = self.__resultsTable.selectedIndexes()[0]
        selected_row = selected_index.row()

        value_item = self.__resultsTable.item(selected_row, 1)
        assert value_item is not None

        text = value_item.text()

        clipboard = QApplication.clipboard()
        assert clipboard is not None
        if platform.system() == "Linux":
            clipboard.setText(text, mode=QClipboard.Mode.Selection)
        clipboard.setText(text, mode=QClipboard.Mode.Clipboard)

    def copy_record(self) -> None:
        selected_index = self.__resultsTable.selectedIndexes()[0]
        selected_row = selected_index.row()

        name_item = self.__resultsTable.item(selected_row, 0)
        assert name_item is not None
        value_item = self.__resultsTable.item(selected_row, 1)
        assert value_item is not None

        text = f"{name_item.text()}: {value_item.text()}"

        clipboard = QApplication.clipboard()
        assert clipboard is not None
        if platform.system() == "Linux":
            clipboard.setText(text, mode=QClipboard.Mode.Selection)
        clipboard.setText(text, mode=QClipboard.Mode.Clipboard)

    def copy_all(self) -> None:
        rows: List[str] = []
        for i in range(self.__resultsTable.rowCount()):
            name_item = self.__resultsTable.item(i, 0)
            assert name_item is not None
            value_item = self.__resultsTable.item(i, 1)
            assert value_item is not None
            rows.append(f"{name_item.text()}: {value_item.text()}")

        full_text = "\n".join(rows)

        clipboard = QApplication.clipboard()
        assert clipboard is not None
        if platform.system() == "Linux":
            clipboard.setText(full_text, mode=QClipboard.Mode.Selection)
        clipboard.setText(full_text, mode=QClipboard.Mode.Clipboard)

    def display_feature(self, feature: PkkFeature) -> None:
        self.__feature = feature

        if feature.subtitle is not None:
            self.__featureSubtitleLabel.setText(f"<i>{feature.subtitle}</i>")
            self.__featureSubtitleLabel.show()
        else:
            self.__featureSubtitleLabel.hide()

        self.__nogeomLabel.setVisible(feature.geometry is None)

        if any(
            (label := field) is not None
            for field in (feature.name, feature.info, feature.by_doc)
        ):
            self.__featureInfoLabel.setText(label)
            self.__featureInfoLabel.show()
        else:
            self.__featureInfoLabel.hide()

        self.__resultsTable.setRowCount(len(feature.fields))

        i = 0
        for field in feature.fields:
            if not field.is_visible:
                continue

            name_value = field.alias
            assert name_value is not None
            if field.style is not None and field.style.startswith(
                "level-padding"
            ):
                padding = int(field.style[field.style.rfind("-") + 1 :]) - 1
                name_value = "    " * padding + name_value

            name_item = QTableWidgetItem(name_value)
            name_tooltip = f"<b>{field.alias}</b>"
            if field.name is not None:
                name_tooltip += f" ({field.name})"
            name_item.setToolTip(name_tooltip)
            name_item.setFlags(name_item.flags() ^ Qt.ItemFlag.ItemIsEditable)
            self.__resultsTable.setItem(i, 0, name_item)

            value = field.display_value
            value_item = QTableWidgetItem(value)
            if field.value != " ":
                value_item.setToolTip(value)
            value_item.setFlags(
                value_item.flags() ^ Qt.ItemFlag.ItemIsEditable
            )
            self.__resultsTable.setItem(i, 1, value_item)

            i += 1

        self.__resultsTable.setRowCount(i)
