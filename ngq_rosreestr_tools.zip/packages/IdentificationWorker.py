import json
import os

from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtCore import QEventLoop, QThread, QUrl, pyqtSignal
from qgis.PyQt.QtNetwork import QNetworkReply, QNetworkRequest
from qgis.PyQt.QtWidgets import QMessageBox

# import ng_network
from .pkk_feature_parser import PkkFeatureParser


class IdentificationWorker(QThread):
    gotData = pyqtSignal(list)
    gotError = pyqtSignal(str)

    def __init__(self, xx, yy, object_type, api_key) -> None:
        super().__init__()
        self.__xx = xx
        self.__yy = yy
        self.__type = object_type
        self.api_key = api_key

        endpoints_path = os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                os.pardir,
                "resources",
                "endpoints.json",
            )
        )
        with open(endpoints_path) as file:
            endpoints = json.load(file)
        self.ng_pkk_features_source = endpoints[
            "ng_pkk_features_by_position_source"
        ]

    def run(self) -> None:
        xx = str(self.__xx)
        yy = str(self.__yy)
        object_type = str(self.__type)

        object_type = 1
        if self.__type == "kvartaly":
            object_type = 2
        if self.__type == "uchastki":
            object_type = 1
        if self.__type == "area":
            object_type = 4
        if self.__type == "oks":
            object_type = 5
        if self.__type == "zouit":
            object_type = 10

        api_key = self.api_key
        if api_key is None:
            QMessageBox.information(
                None, "Внимание!", "Невозможно получить API KEY"
            )
            self.gotError.emit(self.tr("Cannot obtain API Key!"))
            return

        if abs(float(xx)) > 180 or abs(float(yy)) > 90:
            self.gotError.emit(
                self.tr("Worker: %s, %s are wrong coords!") % (xx, yy)
            )
            return

        url = (
            self.ng_pkk_features_source
            + f"?apikey={api_key}&lat={yy}&lon={xx}&cache=include&types={object_type}"
        )

        request = QNetworkRequest(QUrl(url))
        request.setHeader(
            QNetworkRequest.ContentTypeHeader, "application/json"
        )

        qnam = QgsNetworkAccessManager.instance()

        reply1 = qnam.get(request)

        loop = QEventLoop()
        reply1.finished.connect(loop.quit)
        loop.exec_()
        if reply1.error() != QNetworkReply.NoError:
            reply1.deleteLater()
            self.gotError.emit(self.tr("Error getting data from the server"))
            return
        try:
            data = reply1.readAll()
            l1 = json.loads(str(data, "utf-8"))
            reply1.deleteLater()
        except Exception:
            self.gotError.emit(self.tr("Error parsing data"))
            return
        finally:
            reply1.deleteLater()

        try:
            feature_parser = PkkFeatureParser()
            features = [
                feature_parser.parse(feature) for feature in l1["features"]
            ]
        except Exception:
            self.gotError.emit(
                "Возникла ошибка. Не удалось разобрать ответ от сервера"
            )
            return

        self.gotData.emit(features)
