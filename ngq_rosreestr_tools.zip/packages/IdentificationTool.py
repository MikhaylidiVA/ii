from pathlib import Path

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
)
from qgis.gui import QgisInterface, QgsMapMouseEvent, QgsMapTool
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QCursor, QPixmap

from .IdentificationResultsDialog import IdentificationResultsDialog
from .rb_result_renderer import RubberBandResultRenderer


class IdentificationTool(QgsMapTool):
    def __init__(
        self, iface: QgisInterface, object_type: str, api_key: str
    ) -> None:
        super().__init__(iface.mapCanvas())
        self.result_renderer = RubberBandResultRenderer()

        self.canvas = iface.mapCanvas()
        # self.emitPoint = QgsMapToolEmitPoint(self.canvas)
        self.iface = iface
        self.type = object_type
        self.api_key = api_key
        self.__is_pressed = False

        resources_path = Path(__file__).parents[1] / "resources"
        cursor_path = resources_path / "icons" / "identification_cursor.png"

        self.cursor = QCursor(QPixmap(str(cursor_path)), 1, 1)

        self.docWidgetResults = IdentificationResultsDialog(
            "Карточка объекта",
            self.result_renderer,
            parent=self.iface.mainWindow(),
        )
        self.docWidgetResults.setVisible(False)
        self.__doc_added = False

    def __del__(self) -> None:
        self.docWidgetResults.deleteLater()

    def activate(self) -> None:
        self.canvas.setCursor(self.cursor)

    def deactivate(self) -> None:
        self.docWidgetResults.close()

    def set_type(self, object_type: str) -> None:
        self.type = object_type

    def canvasPressEvent(self, event: QgsMapMouseEvent) -> None:
        self.__is_pressed = True

        self.result_renderer.clear()
        self.result_renderer.clear_feature()
        self.canvas.update()

    def canvasMoveEvent(self, event: QgsMapMouseEvent) -> None:
        if not self.__is_pressed:
            return

        x = event.pos().x()
        y = event.pos().y()

        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        crsSrc = self.canvas.mapSettings().destinationCrs()
        crsWGS = QgsCoordinateReferenceSystem.fromEpsgId(4326)
        if crsSrc == QgsCoordinateReferenceSystem() and (
            abs(point.x()) > 10000 or abs(point.y()) > 10000
        ):
            crsSrc = QgsCoordinateReferenceSystem.fromEpsgId(3857)

        xform = QgsCoordinateTransform(crsSrc, crsWGS, QgsProject.instance())
        point = xform.transform(QgsPointXY(point.x(), point.y()))

        self.result_renderer.clear()
        self.result_renderer.clear_feature()
        self.result_renderer.show_point(point, False)

        self.canvas.update()

    def canvasReleaseEvent(self, event) -> None:
        crsSrc = self.canvas.mapSettings().destinationCrs()
        crsWGS = QgsCoordinateReferenceSystem.fromEpsgId(4326)

        x = event.pos().x()
        y = event.pos().y()

        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        if crsSrc == QgsCoordinateReferenceSystem() and (
            abs(point.x()) > 10000 or abs(point.y()) > 10000
        ):
            crsSrc = QgsCoordinateReferenceSystem.fromEpsgId(3857)

        xform = QgsCoordinateTransform(crsSrc, crsWGS, QgsProject.instance())
        point = xform.transform(QgsPointXY(point.x(), point.y()))

        xx = str(point.x())
        yy = str(point.y())

        self.result_renderer.show_point(point, False)
        self.canvas.update()
        if not self.__doc_added:
            self.iface.addTabifiedDockWidget(
                Qt.DockWidgetArea.LeftDockWidgetArea, self.docWidgetResults
            )
            self.__doc_added = True

        self.docWidgetResults.setUserVisible(True)

        self.docWidgetResults.getInfo(xx, yy, self.type, self.api_key)

        self.__is_pressed = False
