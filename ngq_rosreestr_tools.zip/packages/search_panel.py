import os
from functools import partial
from typing import Dict, List, Optional

from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)
from qgis.gui import QgsDockWidget
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QPoint, Qt
from qgis.PyQt.QtGui import QIcon, QMouseEvent
from qgis.PyQt.QtWidgets import QListWidgetItem, QMenu, QMessageBox
from qgis.utils import iface

from . import utils
from .ObjectInfoDialog import ObjectInfoDialog
from .pkk_feature_parser import PkkFeature
from .rb_result_renderer import RubberBandResultRenderer
from .search_history import SearchHistory
from .SearchWorker import SearchWorker

FORM_CLASS, _ = uic.loadUiType(
    os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.pardir,
            "resources",
            "search_panel_ui.ui",
        )
    )
)


class NGQRosreestrToolsSearchPanel(QgsDockWidget, FORM_CLASS):
    crsWGS = QgsCoordinateReferenceSystem.fromEpsgId(4326)
    crsPM = QgsCoordinateReferenceSystem.fromEpsgId(3857)

    plugin_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), os.pardir)
    )

    __result_objects: List[PkkFeature]
    __active_query: Optional[str]
    __cached_results: Dict[str, List[PkkFeature]]

    def __init__(self, api_key=None, parent=None) -> None:
        # init dock
        super().__init__(parent)
        self.setupUi(self)
        self.setObjectName("NGQRosreestrToolsSearchPanel")
        self.iface = iface

        self.__result_objects = []
        self.__active_query = None
        self.__cached_results = {}

        searchPanelSearchButtonIcon = QIcon(
            os.path.join(
                self.plugin_dir, "resources", "icons", "RR-search.svg"
            )
        )
        self.searchPanelSearchButton.setIcon(searchPanelSearchButtonIcon)

        searchPanelCancelButtonIcon = QIcon(
            os.path.join(
                self.plugin_dir, "resources", "icons", "RR-delete-search.svg"
            )
        )
        self.searchPanelCancelButton.setIcon(searchPanelCancelButtonIcon)

        self.progressBar.setVisible(False)

        # connections
        self.searchPanelSearchButton.clicked.connect(self.search)
        self.searchPanelCancelButton.clicked.connect(self.delete_selection)
        self.searchPanelCancelButton.setDisabled(True)

        self.searchPanelResultsList.itemClicked.connect(self.zoom_to_record)
        self.searchPanelResultsList.itemDoubleClicked.connect(self.open_record)

        self.searchPanelResultsList.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self.searchPanelResultsList.customContextMenuRequested.connect(
            self.custom_conetext_menu
        )

        self.worker = None
        self.api_key = api_key

        self.result_renderer = RubberBandResultRenderer()

        self.object_info_dialog = ObjectInfoDialog("Информация об объекте")
        self.detailedWidget.layout().addWidget(self.object_info_dialog)

        try:
            search_history = self.read_search_history()
        except Exception:
            search_history = []

        self.searchPanelCadastreNumberBox.clear()
        self.searchPanelCadastreNumberBox.addItems(search_history)

        self.searchPanelCadastreNumberBox.lineEdit().returnPressed.connect(
            self.search
        )

        self.visibilityChanged.connect(self.__on_visibility_changed)

        self.backButton.setIcon(
            QgsApplication.getThemeIcon("mActionArrowLeft.svg")
        )
        self.backButton.clicked.connect(
            partial(self.searchStack.setCurrentIndex, 0)
        )

    def read_search_history(self):
        search_history = SearchHistory()
        return search_history.items

    def write_new_item_to_search_history(self, item) -> None:
        search_history = SearchHistory()
        search_history.add_item(item)

    def types_by_cn(self, cn: str):
        if cn.find("*") != -1:
            return None

        if cn.find("-") != -1:
            return ["zouit"]

        cn_splitted = cn.split(":")
        if len(cn_splitted) == 1:
            return ["area"]

        if len(cn_splitted) == 3:
            return ["kvartaly"]

        if cn.find("_") != -1:
            return ["uchastki"]

        if len(cn_splitted) == 4:
            return ["uchastki", "oks"]

        return None

    def get_object_by_cn(self, cn: str):
        for feature in self.__result_objects:
            if feature.object_id == cn:
                return feature
        return None

    def zoom_to_record(self, item: QListWidgetItem) -> None:
        self.result_renderer.clear_feature()
        self.result_renderer.clear()

        clicked_cn = item.data(Qt.ItemDataRole.UserRole)
        feature = self.get_object_by_cn(clicked_cn)
        assert feature is not None
        if feature.geometry is None:
            return

        geometry = QgsGeometry(feature.geometry)

        canvas = iface.mapCanvas()
        if abs(geometry.vertexAt(0).y()) < 90:
            xform = QgsCoordinateTransform(
                self.crsWGS,
                canvas.mapSettings().destinationCrs(),
                QgsProject.instance(),
            )
        else:
            xform = QgsCoordinateTransform(
                self.crsPM,
                canvas.mapSettings().destinationCrs(),
                QgsProject.instance(),
            )

        transformed_geom = QgsGeometry(geometry)
        transformed_geom.transform(xform)
        bounding_box = transformed_geom.boundingBox()

        self.result_renderer.show_feature(transformed_geom, False)

        canvas.setExtent(bounding_box)
        canvas.refresh()

        # if info dialog already opened
        if self.object_info_dialog.isVisible():
            feature = self.get_object_by_cn(clicked_cn)
            assert feature is not None
            self.object_info_dialog.display_feature(feature)

        self.searchPanelCancelButton.setEnabled(True)

    def open_record(self, item: QListWidgetItem) -> None:
        clicked_cn = item.data(Qt.ItemDataRole.UserRole)
        feature = self.get_object_by_cn(clicked_cn)
        assert feature is not None
        self.object_info_dialog.display_feature(feature)
        self.detailedPageTitleLabel.setText(
            f"<b>{feature.title} {feature.object_id}</b>"
            if feature.title is not None
            else f"<b>{feature.object_id}</b>"
        )

        self.searchStack.setCurrentIndex(1)

    def search(self) -> None:
        if self.api_key is None:
            QMessageBox.information(
                None,
                "Внимание!",
                "Невозможно получить ключ API для инструментов Росреестра",
            )
            return

        self.searchPanelResultsList.clear()
        self.result_renderer.clear_feature()
        self.result_renderer.clear()
        self.searchPanelCancelButton.setDisabled(True)

        self.__result_objects = []

        cn = self.searchPanelCadastreNumberBox.currentText()
        if not cn:
            return

        # History
        self.write_new_item_to_search_history(cn)
        try:
            search_history = self.read_search_history()
        except Exception:
            search_history = []
        self.searchPanelCadastreNumberBox.clear()
        self.searchPanelCadastreNumberBox.addItems(search_history)

        cn = cn.replace("/", "_")

        # Get type
        types = self.types_by_cn(cn)
        if types is None:
            self.statusLabel.setText(
                "Недопустимый кадастровый номер. Поиск отменён"
            )
            return

        self.progressBar.setVisible(True)
        self.searchPanelSearchButton.setDisabled(True)
        self.statusLabel.setText("Осуществляется поиск...")

        if self.worker:
            self.__active_query = None
            self.worker.gotData.disconnect(self.showData)
            self.worker.gotError.disconnect(self.showError)
            self.worker.quit()
            self.worker.deleteLater()
            self.worker = None

        self.__active_query = cn

        if cn in self.__cached_results:
            self.showData(self.__cached_results[cn])
            return

        self.worker = SearchWorker(cn, types, self.api_key)
        self.worker.gotData.connect(self.showData)
        self.worker.gotError.connect(self.showError)
        self.worker.start()

    def showError(self, msg: str) -> None:
        self.statusLabel.setText(f"Возникла ошибка: {msg}")
        self.progressBar.setVisible(False)
        self.searchPanelSearchButton.setEnabled(True)
        self.__active_query = None

    def showData(self, features: List[PkkFeature]) -> None:
        if len(features) == 0:
            self.statusLabel.setText("Не найдено объектов с указанным номером")
        else:
            if self.__active_query not in self.__cached_results:
                self.__cached_results[self.__active_query] = features
            self.__active_query = None

            self.statusLabel.setText(
                "Поиск завершён. Выберите нужную запись мышью для перехода к"
                + " объекту, двойной клик откроет карточку со свойствами"
            )

            self.__result_objects = features

            for feature in self.__result_objects:
                item = QListWidgetItem(
                    f"{feature.title} {feature.object_id}"
                    if feature.title is not None
                    else feature.object_id,
                    self.searchPanelResultsList,
                )
                item.setData(Qt.ItemDataRole.UserRole, feature.object_id)

        self.progressBar.setVisible(False)
        self.searchPanelSearchButton.setEnabled(True)

    def delete_selection(self) -> None:
        self.result_renderer.clear_feature()
        self.result_renderer.clear()
        self.searchPanelResultsList.clearSelection()

        self.searchPanelCancelButton.setDisabled(True)

        if self.worker is not None and self.worker.isRunning():
            self.worker.quit()
            self.statusLabel.setText("Поиск отменен")
            self.progressBar.setVisible(False)
            self.searchPanelSearchButton.setEnabled(True)

    def custom_conetext_menu(self, position: QPoint) -> None:
        item = self.searchPanelResultsList.itemAt(position)

        if item is None:
            return

        cad_number = item.data(Qt.ItemDataRole.UserRole)

        submenu = QMenu()
        new_layer_action = submenu.addAction("Добавить объект в новый слой")
        new_layer_action.triggered.connect(
            partial(self.__add_feature_to_new_layer, cad_number)
        )

        active_layer_action = submenu.addAction(
            "Добавить объект в активный слой"
        )
        active_layer_action.triggered.connect(
            partial(self.__add_feature_to_existed_layer, cad_number)
        )
        active_layer = iface.mapCanvas().currentLayer()
        if not isinstance(active_layer, QgsVectorLayer):
            active_layer_action.setDisabled(True)

        submenu.exec_(self.searchPanelResultsList.mapToGlobal(position))

    def __add_feature_to_new_layer(self, cad_nubmer: str) -> None:
        feature = self.get_object_by_cn(cad_nubmer)
        assert feature is not None
        utils.add_to_new_layer(feature)

        self.delete_selection()

    def __add_feature_to_existed_layer(self, cad_nubmer: str) -> None:
        feature = self.get_object_by_cn(cad_nubmer)
        assert feature is not None
        utils.add_to_active_layer(feature)

        self.delete_selection()

    def __on_visibility_changed(self, is_visible: bool) -> None:
        if not is_visible:
            self.searchStack.setCurrentIndex(0)
            self.delete_selection()

    def mouseReleaseEvent(self, a0: Optional[QMouseEvent]) -> None:
        if a0 is not None and a0.button() == Qt.MouseButton.BackButton:
            self.searchStack.setCurrentIndex(0)
            return

        super().mouseReleaseEvent(a0)
