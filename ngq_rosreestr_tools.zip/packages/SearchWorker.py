import json
import os

from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtCore import QEventLoop, QThread, QUrl, pyqtSignal
from qgis.PyQt.QtNetwork import QNetworkReply, QNetworkRequest
from qgis.PyQt.QtWidgets import QMessageBox

from .egrn_tools_settings import EgrnToolsSettings
from .pkk_feature_parser import PkkFeatureParser


class SearchWorker(QThread):
    gotData = pyqtSignal(list)
    gotError = pyqtSignal(str)

    def __init__(self, object_id, types, api_key) -> None:
        super().__init__()
        self.__id = object_id
        self.__types = types
        self.api_key = api_key

        endpoints_path = os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                os.pardir,
                "resources",
                "endpoints.json",
            )
        )
        with open(endpoints_path) as file:
            endpoints = json.load(file)

        self.ng_pkk_features_by_id_source = endpoints[
            "ng_pkk_features_by_id_source"
        ]

    def run(self) -> None:
        if EgrnToolsSettings().is_developer_mode:
            import debugpy  # noqa: T100

            if debugpy.is_client_connected():
                debugpy.debug_this_thread()

        object_id = str(self.__id)

        api_key = self.api_key
        if api_key is None:
            QMessageBox.information(
                None, "Внимание!", "Невозможно получить API KEY"
            )
            self.gotError.emit(self.tr("Cannot obtain API Key!"))
            return

        total_reply = []

        for object_type in self.__types:
            current_reply = {}

            if object_type == "uchastki":
                object_type = 1
            elif object_type == "kvartaly":
                object_type = 2
            elif object_type == "area":
                object_type = 4
            elif object_type == "oks":
                object_type = 5
            elif object_type == "zouit":
                object_type = 10

            url = (
                self.ng_pkk_features_by_id_source
                + f"?apikey={api_key}&id={object_id}&type={object_type}"
            )

            request = QNetworkRequest(QUrl(url))
            request.setHeader(
                QNetworkRequest.ContentTypeHeader, "application/json"
            )

            qnam = QgsNetworkAccessManager.instance()

            reply1 = qnam.get(request)

            loop = QEventLoop()
            reply1.finished.connect(loop.quit)
            loop.exec_()

            if reply1.error() != QNetworkReply.NoError:
                status_code = reply1.attribute(
                    QNetworkRequest.HttpStatusCodeAttribute
                )

                if status_code == 404:
                    current_reply["status"] = "ok"
                    current_reply["data"] = []
                    reply1.deleteLater()
                    total_reply.append(current_reply)
                    continue

                reply1.deleteLater()
                current_reply["status"] = "server-error"
                total_reply.append(current_reply)
                continue

            try:
                data = reply1.readAll()
                if str(data) == "":
                    current_reply["status"] = "ok"
                    current_reply["data"] = {}
                    reply1.deleteLater()
                    total_reply.append(current_reply)
                    continue

                l1 = json.loads(str(data, "utf-8"))
                current_reply["status"] = "ok"
                current_reply["data"] = l1
                reply1.deleteLater()
            except Exception:
                current_reply["status"] = "parse-error"
            finally:
                reply1.deleteLater()

            total_reply.append(current_reply)

        error = True
        feature_parser = PkkFeatureParser()
        for reply in total_reply:
            if reply["status"] != "ok":
                continue

            error = False
            if len(reply["data"]) != 0:
                try:
                    features = [
                        feature_parser.parse(feature)
                        for feature in reply["data"]["features"]
                    ]
                except Exception:
                    self.gotError.emit(
                        "Возникла ошибка. Не удалось разобрать ответ от сервера"
                    )
                    return

                self.gotData.emit(features)
                return

        if error:
            self.gotError.emit("Невозможно получить данные")
        else:
            self.gotData.emit([])
