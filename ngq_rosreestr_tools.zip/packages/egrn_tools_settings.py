from qgis.core import QgsSettings
from qgis.PyQt.QtCore import QDir


class EgrnToolsSettings:
    __settings: QgsSettings

    def __init__(self) -> None:
        self.__settings = QgsSettings()
        self.__migrate()

    @property
    def is_developer_mode(self) -> bool:
        return self.__settings.value(
            "NextGIS/Plugins/other/developerMode",
            defaultValue=False,
            type=bool,
        )

    @is_developer_mode.setter
    def is_developer_mode(self, value: bool) -> None:
        self.__settings.setValue("NextGIS/Plugins/other/developerMode", value)

    @property
    def last_source_dir(self) -> str:
        return self.__settings.value(
            self.__group + "/lastSourceDir",
            defaultValue=QDir.homePath(),
            type=str,
        )

    @last_source_dir.setter
    def last_source_dir(self, value: str) -> None:
        self.__settings.setValue(self.__group + "/lastSourceDir", value)

    @property
    def last_destination_dir(self) -> str:
        return self.__settings.value(
            self.__group + "/lastDestinationDir",
            defaultValue=QDir.homePath(),
            type=str,
        )

    @last_destination_dir.setter
    def last_destination_dir(self, value: str) -> None:
        self.__settings.setValue(self.__group + "/lastDestinationDir", value)

    @property
    def last_used_driver(self) -> str:
        return self.__settings.value(
            self.__group + "/lastUsedDriver", defaultValue="GPKG", type=str
        )

    @last_used_driver.setter
    def last_used_driver(self, value: str) -> None:
        self.__settings.setValue(self.__group + "/lastUsedDriver", value)

    @property
    def skip_nogeom_features(self) -> bool:
        return self.__settings.value(
            self.__group + "/skipNogeomFeatures", defaultValue=False, type=bool
        )

    @skip_nogeom_features.setter
    def skip_nogeom_features(self, value: bool) -> None:
        self.__settings.setValue(self.__group + "/skipNogeomFeatures", value)

    @property
    def remove_empty_attributes(self) -> bool:
        return self.__settings.value(
            self.__group + "/removeEmptyAttributes",
            defaultValue=False,
            type=bool,
        )

    @remove_empty_attributes.setter
    def remove_empty_attributes(self, value: bool) -> None:
        self.__settings.setValue(
            self.__group + "/removeEmptyAttributes", value
        )

    @property
    def parse_extra_data(self) -> bool:
        return self.__settings.value(
            self.__group + "/parseExtraData", defaultValue=True, type=bool
        )

    @parse_extra_data.setter
    def parse_extra_data(self, value: bool) -> None:
        self.__settings.setValue(self.__group + "/parseExtraData", value)

    @property
    def merge_unrecognized(self) -> bool:
        return self.__settings.value(
            self.__group + "/mergeUnrecognized", defaultValue=False, type=bool
        )

    @merge_unrecognized.setter
    def merge_unrecognized(self, value: bool) -> None:
        self.__settings.setValue(self.__group + "/mergeUnrecognized", value)

    @property
    def add_result_to_project(self) -> bool:
        return self.__settings.value(
            self.__group + "/addResultToProject", defaultValue=True, type=bool
        )

    @add_result_to_project.setter
    def add_result_to_project(self, value: bool) -> None:
        self.__settings.setValue(self.__group + "/addResultToProject", value)

    @property
    def __group(self) -> str:
        return "NextGIS/EgrnTools"

    def __migrate(self) -> None:
        last_source_dir = self.__settings.value(
            "NextGIS/RosreestrTools/lastSourceDir"
        )
        if last_source_dir is not None:
            self.last_source_dir = last_source_dir
            self.__settings.remove("NextGIS/RosreestrTools/lastSourceDir")

        last_destination_dir = self.__settings.value(
            "NextGIS/RosreestrTools/lastDestinationDir"
        )
        if last_destination_dir is not None:
            self.last_destination_dir = last_destination_dir
            self.__settings.remove("NextGIS/RosreestrTools/lastDestinationDir")

        need_transform = self.__settings.value(self.__group + "/needTransform")
        if need_transform is not None:
            self.__settings.remove(self.__group + "/needTransform")

        self.__settings.sync()
