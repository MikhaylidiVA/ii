import json
import os

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QWidget

FORM_CLASS, _ = uic.loadUiType(
    os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.pardir,
            "resources",
            "settings_window.ui",
        )
    )
)


class NGQRosreestrToolsSettingsWindow(QWidget, FORM_CLASS):
    plugin_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), os.pardir)
    )
    keys_file = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), os.pardir, "resources", "keys.json"
        )
    )

    def __init__(self, api_key=None, parent=None) -> None:
        # init dock
        super().__init__(parent)
        self.setupUi(self)

        self.geoservicesLabel.setOpenExternalLinks(True)
        self.toolboxLabel.setOpenExternalLinks(True)

        self.SettingsWindowSaveButton.clicked.connect(self.save)
        self.SettingsWindowCancelButton.clicked.connect(self.cancel)

        if not os.path.exists(self.keys_file):
            self.keys = {"toolbox_token": "", "geoservices_api_key": ""}

            with open(self.keys_file, "w") as fh:
                fh.write(json.dumps(self.keys))
        else:
            with open(self.keys_file) as fh:
                self.keys = json.loads(fh.read())

        if (not self.keys.get("geoservices_api_key")) and (
            not self.keys.get("toolbox_token")
        ):
            self.keys = {"toolbox_token": "", "geoservices_api_key": ""}
            with open(self.keys_file, "w") as fh:
                fh.write(json.dumps(self.keys))

        self.SettingsWindowGeoservicesAPIKey.setText(
            self.keys["geoservices_api_key"]
        )
        self.SettingsWindowToolboxToken.setText(self.keys["toolbox_token"])

    def save(self) -> None:
        new_geoservices_key = self.SettingsWindowGeoservicesAPIKey.text()
        new_toolbox_token = self.SettingsWindowToolboxToken.text()

        self.keys = {
            "toolbox_token": new_toolbox_token,
            "geoservices_api_key": new_geoservices_key,
        }

        with open(self.keys_file, "w") as fh:
            fh.write(json.dumps(self.keys))

        self.close()

    def cancel(self) -> None:
        self.close()
