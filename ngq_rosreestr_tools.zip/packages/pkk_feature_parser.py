import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from osgeo import ogr
from qgis.core import QgsGeometry
from qgis.PyQt.QtCore import QLocale


@dataclass
class PkkField:
    name: Optional[str]
    alias: Optional[str]
    value: Optional[str]
    style: Optional[str]
    is_visible: bool = True
    can_have_formatted_value: bool = False
    formatted_value: Optional[str] = None

    @property
    def display_value(self) -> str:
        if self.formatted_value is not None:
            return self.formatted_value
        if self.value is not None:
            return self.value
        return "-"


@dataclass
class PkkFeature:
    type_id: int
    object_id: str
    name: Optional[str] = None
    title: Optional[str] = None
    subtitle: Optional[str] = None
    info: Optional[str] = None
    by_doc: Optional[str] = None
    fields: List[PkkField] = field(default_factory=list)
    geometry: Optional[QgsGeometry] = None

    def __getitem__(self, key: str) -> Optional[PkkField]:
        if any((found_field := field).name == key for field in self.fields):
            return found_field
        return None


class PkkFeatureParser:
    """Парсер ответов ПКК"""

    _structure: Dict[int, Dict[str, Any]]
    _dictionary: Dict[str, Dict[str, str]]

    def __init__(self) -> None:
        self._structure = {}
        self._dictionary = {}

    def parse(self, object_dict: Dict[str, Any]) -> PkkFeature:
        headings: Dict[str, str] = {}
        fields: List[PkkField] = []

        properties: Dict[str, Any] = object_dict["properties"]
        object_id = self._get_id(properties)
        type_id = int(properties["type"])
        structure = self._get_structure(type_id)

        for structure_field in self._get_fields(structure, properties):
            if self._need_skip(structure_field):
                continue

            field = PkkField(
                name=structure_field.get("prop"),
                alias=self._get_field_alias(structure_field, properties),
                value=self._get_field_value(structure_field, properties),
                style=structure_field.get("style"),
            )
            field.is_visible = self._get_field_visibility(
                structure_field, properties, field.value
            )
            field.can_have_formatted_value = self._can_have_formatted_value(
                structure_field
            )
            if field.can_have_formatted_value:
                field.formatted_value = self._get_formatted_value(
                    structure_field, properties, field.value
                )

            fields.append(field)

            headings.update(self._get_headings(structure_field, field.value))

        geometry = None
        if (geometry_json := object_dict["geometry"]) is not None:
            geometry = self.qgsgeometry_from_geojson(geometry_json)

        feature = PkkFeature(
            type_id=type_id,
            object_id=object_id,
            name=headings.get("name"),
            title=headings.get("title"),
            subtitle=headings.get("subtitle"),
            info=headings.get("info"),
            by_doc=headings.get("by_doc"),
            fields=fields,
            geometry=geometry,
        )

        self._postprocess_feature(feature)

        return feature

    def _get_structure(self, type_id: int) -> Dict[str, Any]:
        if type_id in self._structure:
            return self._structure[type_id]

        pkk_path = Path(__file__).parents[1] / "resources" / "pkk"
        structure_path = pkk_path / "structure" / f"{type_id}.json"

        with open(structure_path) as structure_file:
            self._structure[type_id] = json.load(structure_file)

        return self._structure[type_id]

    def _get_dictionary(self, dictionary_name: str) -> Dict[str, str]:
        if dictionary_name in self._dictionary:
            return self._dictionary[dictionary_name]

        pkk_path = Path(__file__).parents[1] / "resources" / "pkk"
        dictionary_path = pkk_path / "dictionaries" / f"{dictionary_name}.json"

        with open(dictionary_path) as dictionary_file:
            self._dictionary[dictionary_name] = json.load(dictionary_file)

        return self._dictionary[dictionary_name]

    def _get_id(self, properties: Dict[str, Any]) -> str:
        if any(
            properties.get(id_key := key) is not None
            for key in ["cn", "number_zone"]
        ):
            return properties[id_key]

        return properties["id"]

    def _get_fields(
        self, structure: Dict[str, Any], properties: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        parcel_type = properties.get("parcel_type")
        fields_key = "fields"
        if parcel_type is not None:
            fields_key = f"{fields_key}_{parcel_type}"
        elif "/" in properties.get("cn", ""):
            fields_key = "fields_parcel_mzu_contour"
        return structure[fields_key]

    def _need_skip(self, structure_field: Dict[str, Any]) -> bool:
        parent_prop = structure_field.get("parentProp", "")
        need_skip = structure_field.get("skip", False)
        return need_skip or (parent_prop != "attrs" and parent_prop != "")

    def _get_field_alias(
        self, structure_field: Dict[str, Any], properties: Dict[str, Any]
    ) -> Optional[str]:
        alias: Optional[str] = structure_field.get("alias")
        if (alias_prop := structure_field.get("aliasProp")) is None:
            return alias

        alias_value = properties[alias_prop]
        if (dictionary_name := structure_field.get("aliasDictionary")) is None:
            alias = alias_value
        else:
            alias_dictionary = self._get_dictionary(dictionary_name)
            alias = alias_dictionary[alias_value]

        return alias

    def _get_field_value(
        self, structure_field: Dict[str, Any], properties: Dict[str, Any]
    ) -> Optional[str]:
        value = structure_field.get("value")

        if value is None:
            property_field: Optional[str] = structure_field.get("field")
            if property_field is None:
                property_field = structure_field.get("prop")
            if property_field is not None:
                value = properties.get(property_field)

        if value is None:
            return value

        if isinstance(value, float) and value.is_integer():
            value = str(int(value))
        else:
            value = str(value)

        dictionary_name = structure_field.get("dictionary")
        if isinstance(dictionary_name, str):
            dictionary = self._get_dictionary(dictionary_name)
            value = dictionary.get(value, value)

        return value

    def _get_field_visibility(
        self,
        structure_field: Dict[str, Any],
        properties: Dict[str, Any],
        display_condition: Optional[str],
    ) -> bool:
        is_visible = structure_field.get("visible", True)

        hide_when_empty = structure_field.get("hideWhenEmpty", False)
        if hide_when_empty and display_condition is None:
            is_visible = False

        display_condition_property = structure_field.get("displayCondition")
        if isinstance(display_condition_property, str):
            display_condition = properties[display_condition_property]
            condition_value = structure_field.get("displayConditionValue")
            is_visible_by_condition = True
            if isinstance(condition_value, list):
                is_visible_by_condition = display_condition in condition_value
            elif condition_value is not None:
                is_visible_by_condition = display_condition == condition_value
            else:
                # Example: type=15, prop=address, address_info
                # Current behavior is an assumtion, verification is needed
                is_visible_by_condition = (
                    properties[display_condition_property] is not None
                )

            is_visible = is_visible and is_visible_by_condition

        return is_visible

    def _can_have_formatted_value(
        self, structure_field: Dict[str, Any]
    ) -> bool:
        return (
            any(
                key in structure_field
                for key in ["format", "dimension", "constDimension"]
            )
            and structure_field.get("format") != "date"
        )

    def _get_formatted_value(
        self,
        structure_field: Dict[str, Any],
        properties: Dict[str, Any],
        value: Optional[str],
    ) -> Optional[str]:
        if value is None:
            return None

        field_format = structure_field.get("format")
        if field_format == "number":
            locale = QLocale("ru_RU")
            value = locale.toString(float(value), "f", 2)
            if "," in value:
                value = value.rstrip("0").rstrip(",")
        elif field_format == "date":
            pass

        dimension_suffix: Optional[str] = None
        if (dimension := structure_field.get("dimension")) is not None:
            dimension_key = str(properties[dimension])
            dictionary_name = structure_field.get("dictionaryDimension")
            assert dictionary_name is not None
            dimension_dictionary = self._get_dictionary(dictionary_name)
            dimension_suffix = dimension_dictionary[dimension_key]

        const_dimension = structure_field.get("constDimension")
        if const_dimension is not None:
            dimension_suffix = const_dimension

        if dimension_suffix is not None:
            value = f"{value} {dimension_suffix}"

        return value

    def _get_headings(
        self, structure_field: Dict[str, Any], value: Optional[str]
    ) -> Dict[str, str]:
        result: Dict[str, str] = {}

        if structure_field.get("prop") == "name" and value is not None:
            result["name"] = value

        identity_field = structure_field.get("identifyField")
        if identity_field is not None and identity_field["isTitle"]:
            identity_name = identity_field.get("name")
            identity_value = identity_field.get("value", value)
            result[identity_name] = identity_value

        return result

    def _postprocess_feature(self, feature: PkkFeature) -> None:
        if feature.type_id == 1:  # Земельный участок
            if (
                parent_cn := feature["parent_cn"]
            ) is not None and parent_cn.value is not None:
                land_type_field = feature["land_type"]
                assert land_type_field is not None
                land_type_field.value = "Земельный участок в составе ЕЗП"
        elif (
            feature.type_id == 4 and feature.name is not None
        ):  # Кадастровый округ
            feature.name += " кадастровый округ"

    @staticmethod
    def qgsgeometry_from_geojson(geojson: Dict[str, Any]) -> QgsGeometry:
        ogr_geom = ogr.CreateGeometryFromJson(json.dumps(geojson))
        wkt_geom = ogr_geom.ExportToWkt()
        return QgsGeometry.fromWkt(wkt_geom)
