import platform
from typing import List, Optional

from qgis.core import QgsGeometry, QgsVectorLayer
from qgis.gui import QgsDockWidget, QgsGui
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QClipboard, QShowEvent
from qgis.PyQt.QtWidgets import (
    QAction,
    QApplication,
    QComboBox,
    QLabel,
    QMenu,
    QProgressBar,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qgis.utils import iface

from . import utils
from .IdentificationWorker import IdentificationWorker
from .pkk_feature_parser import PkkFeature, PkkFeatureParser


class IdentificationResultsDialog(QgsDockWidget):
    def __init__(self, title, result_render, parent=None) -> None:
        self.__rb = result_render
        super().__init__(title, parent)
        self.setObjectName("IdentificationResultsDialog")
        QgsGui.enableAutoGeometryRestore(self)

        self.__mainWidget = QWidget()
        self.__layout = QVBoxLayout(self.__mainWidget)
        self.worker = None

        self.__featureCombobox = QComboBox(self)
        self.__featureCombobox.currentIndexChanged.connect(
            self.change_active_feature
        )

        self.__infoLabel = QLabel(self)
        self.__infoLabel.setText("Получение сведений об объектах...")
        self.__infoLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.__featureSubtitleLabel = QLabel(self)
        self.__featureSubtitleLabel.setWordWrap(True)
        self.__featureSubtitleLabel.hide()
        self.__featureInfoLabel = QLabel(self)
        self.__featureInfoLabel.setWordWrap(True)
        self.__featureInfoLabel.hide()

        self.__resultsTable = QTableWidget(self)
        vertical_header = self.__resultsTable.verticalHeader()
        assert vertical_header is not None
        vertical_header.hide()
        self.__resultsTable.setAlternatingRowColors(True)
        self.__resultsTable.setMinimumSize(350, 250)
        self.__resultsTable.setColumnCount(2)
        self.__resultsTable.setRowCount(0)
        self.__resultsTable.setColumnWidth(0, 180)
        horizontal_header = self.__resultsTable.horizontalHeader()
        assert horizontal_header is not None
        horizontal_header.setStretchLastSection(True)

        self.__resultsTable.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self.__resultsTable.customContextMenuRequested.connect(self.openMenu)

        self.__resultsTable.setHorizontalHeaderLabels(["Параметр", "Значение"])
        self.__resultsTable.setDisabled(True)

        self.__progressBar = QProgressBar(self)
        self.__progressBar.setMinimum(0)
        self.__progressBar.setMaximum(0)
        self.__progressBar.setMinimumSize(250, 14)
        self.__progressBar.setVisible(False)
        self.__progressBar.setTextVisible(False)

        self.__layout.addWidget(self.__infoLabel)
        self.__layout.addWidget(self.__featureCombobox)
        self.__layout.addWidget(self.__featureSubtitleLabel)
        self.__layout.addWidget(self.__featureInfoLabel)
        self.__layout.addWidget(self.__resultsTable)
        self.__layout.addWidget(self.__progressBar)

        self.setWidget(self.__mainWidget)

        self.__feature_parser = PkkFeatureParser()
        self.__features: List[PkkFeature] = []

    def openMenu(self, position) -> None:
        selected_items = self.__resultsTable.selectedItems()

        if len(selected_items) > 0:
            menu = QMenu()

            # actionZoom = QAction(
            #   QIcon(':/plugins/osminfo/icons/zoom2feature.png'),
            #   self.tr('Zoom to feature'),
            #   self)
            actionCopyAttr = QAction("Скопировать атрибут", self)
            menu.addAction(actionCopyAttr)
            actionCopyAttr.setStatusTip("Скопировать атрибут")
            actionCopyAttr.triggered.connect(self.copy_attr)

            actionCopyRecord = QAction("Скопировать запись", self)
            menu.addAction(actionCopyRecord)
            actionCopyRecord.setStatusTip("Скопировать запись")
            actionCopyRecord.triggered.connect(self.copy_record)

            actionCopyAll = QAction("Скопировать всё", self)
            menu.addAction(actionCopyAll)
            actionCopyAll.setStatusTip("Скопировать всё")
            actionCopyAll.triggered.connect(self.copy_all)

            menu.addSeparator()

            actionCreateLayer = QAction("Добавить объект в новый слой", self)
            menu.addAction(actionCreateLayer)
            actionCreateLayer.setStatusTip("Добавить объект в новый слой")
            actionCreateLayer.triggered.connect(self.create_layer)

            actionAddFeature = QAction("Добавить объект в активный слой", self)
            menu.addAction(actionAddFeature)
            actionAddFeature.setStatusTip("Добавить объект в активный слой")
            actionAddFeature.triggered.connect(self.add_feature)
            active_layer = iface.mapCanvas().currentLayer()
            if not isinstance(active_layer, QgsVectorLayer):
                actionAddFeature.setDisabled(True)

            # actionZoom.triggered.connect(self.zoom2feature)

            viewport = self.__resultsTable.viewport()
            assert viewport is not None

            menu.exec_(viewport.mapToGlobal(position))

    def create_layer(self) -> None:
        if (index := self.__featureCombobox.currentIndex()) == -1:
            return

        utils.add_to_new_layer(self.__features[index])

    def add_feature(self) -> None:
        if (index := self.__featureCombobox.currentIndex()) == -1:
            return

        utils.add_to_active_layer(self.__features[index])

    def copy_attr(self) -> None:
        selected_index = self.__resultsTable.selectedIndexes()[0]
        selected_row = selected_index.row()

        value_item = self.__resultsTable.item(selected_row, 1)
        assert value_item is not None

        text = value_item.text()

        clipboard = QApplication.clipboard()
        assert clipboard is not None
        if platform.system() == "Linux":
            clipboard.setText(text, mode=QClipboard.Mode.Selection)
        clipboard.setText(text, mode=QClipboard.Mode.Clipboard)

    def copy_record(self) -> None:
        selected_index = self.__resultsTable.selectedIndexes()[0]
        selected_row = selected_index.row()

        name_item = self.__resultsTable.item(selected_row, 0)
        assert name_item is not None
        value_item = self.__resultsTable.item(selected_row, 1)
        assert value_item is not None

        text = f"{name_item.text()}: {value_item.text()}"

        clipboard = QApplication.clipboard()
        assert clipboard is not None
        if platform.system() == "Linux":
            clipboard.setText(text, mode=QClipboard.Mode.Selection)
        clipboard.setText(text, mode=QClipboard.Mode.Clipboard)

    def copy_all(self) -> None:
        rows: List[str] = []
        for i in range(self.__resultsTable.rowCount()):
            name_item = self.__resultsTable.item(i, 0)
            assert name_item is not None
            value_item = self.__resultsTable.item(i, 1)
            assert value_item is not None
            rows.append(f"{name_item.text()}: {value_item.text()}")

        full_text = "\n".join(rows)

        clipboard = QApplication.clipboard()
        assert clipboard is not None
        if platform.system() == "Linux":
            clipboard.setText(full_text, mode=QClipboard.Mode.Selection)
        clipboard.setText(full_text, mode=QClipboard.Mode.Clipboard)

    def getInfo(self, xx, yy, object_type, api_key) -> None:
        self.__features = []
        self.__rb.clear_feature()
        self.__rb.clear()
        self.__featureSubtitleLabel.hide()
        self.__featureInfoLabel.hide()
        self.__resultsTable.clearContents()
        self.__resultsTable.setRowCount(0)
        self.__resultsTable.setDisabled(True)
        self.__featureCombobox.clear()
        self.__featureCombobox.setDisabled(True)
        self.__infoLabel.setText("Получение сведений об объектах...")
        self.__progressBar.setVisible(True)
        if self.worker:
            self.worker.gotData.disconnect(self.showData)
            self.worker.gotError.disconnect(self.showError)
            self.worker.quit()
            self.worker.deleteLater()

        worker = IdentificationWorker(xx, yy, object_type, api_key)
        worker.gotData.connect(self.showData)
        worker.gotError.connect(self.showError)
        worker.start()

        self.worker = worker

    def showError(self, msg) -> None:
        self.__infoLabel.setText(
            "Возникла ошибка. Невозможно получить информацию."
        )
        self.__featureCombobox.setDisabled(True)
        self.__resultsTable.setDisabled(True)
        self.__progressBar.setVisible(False)

    def change_active_feature(self) -> None:
        if len(self.__features) == 0:
            return

        self.__featureCombobox.setEnabled(True)

        feature = self.__features[self.__featureCombobox.currentIndex()]
        if feature.subtitle is not None:
            self.__featureSubtitleLabel.setText(f"<i>{feature.subtitle}</i>")
            self.__featureSubtitleLabel.show()

        if any(
            (label := field) is not None
            for field in (feature.name, feature.info, feature.by_doc)
        ):
            self.__featureInfoLabel.setText(label)
            self.__featureInfoLabel.show()

        self.__resultsTable.setRowCount(len(feature.fields))

        i = 0
        for field in feature.fields:
            if not field.is_visible:
                continue

            name_value = field.alias
            assert name_value is not None
            if field.style is not None and field.style.startswith(
                "level-padding"
            ):
                padding = int(field.style[field.style.rfind("-") + 1 :]) - 1
                name_value = "    " * padding + name_value

            name_item = QTableWidgetItem(name_value)
            name_tooltip = f"<b>{field.alias}</b>"
            if field.name is not None:
                name_tooltip += f" ({field.name})"
            name_item.setToolTip(name_tooltip)
            name_item.setFlags(name_item.flags() ^ Qt.ItemFlag.ItemIsEditable)
            self.__resultsTable.setItem(i, 0, name_item)

            value = field.display_value
            value_item = QTableWidgetItem(value)
            if field.value != " ":
                value_item.setToolTip(value)
            value_item.setFlags(
                value_item.flags() ^ Qt.ItemFlag.ItemIsEditable
            )
            self.__resultsTable.setItem(i, 1, value_item)

            i += 1

        self.__resultsTable.setRowCount(i)

        # Geometry handling
        geometry = QgsGeometry(feature.geometry)
        assert geometry is not None

        transform = False
        if abs(geometry.vertexAt(0).y()) < 90:
            transform = True
        self.__rb.show_feature(geometry, transform)

    def showData(self, features) -> None:
        if len(features) == 0:
            self.__infoLabel.setText("Нет объектов в запрошенной точке")
            self.__resultsTable.setDisabled(True)
            self.__progressBar.setVisible(False)
            return

        self.__infoLabel.setText(f"Найдено объектов: {len(features)}")

        self.__features = features

        feature_names: List[str] = []
        for feature in self.__features:
            if feature.title is not None:
                feature_names.append(f"{feature.title} {feature.object_id}")
            else:
                feature_names.append(feature.object_id)

        self.__featureCombobox.blockSignals(True)
        self.__featureCombobox.addItems(feature_names)
        self.__featureCombobox.setCurrentIndex(0)
        self.__featureCombobox.blockSignals(False)

        self.change_active_feature()

        self.__progressBar.setVisible(False)
        self.__resultsTable.setEnabled(True)

    def showEvent(self, event: Optional[QShowEvent]) -> None:
        self.change_active_feature()
        return super().showEvent(event)

    def closeEvent(self, event) -> None:
        self.__rb.clear_feature()
        self.__rb.clear()
