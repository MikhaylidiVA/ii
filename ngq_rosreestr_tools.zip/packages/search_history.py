from typing import List

from qgis.core import QgsSettings


class SearchHistory:
    __settings: QgsSettings

    def __init__(self) -> None:
        self.__settings = QgsSettings()

    @property
    def max_size(self) -> int:
        return self.__settings.value(self.__group + "/maxSize", 5)

    @max_size.setter
    def max_size(self, value: int) -> None:
        self.__settings.setValue(self.__group + "/maxSize", value)

    @property
    def items(self) -> List[str]:
        return self.__settings.value(self.__group + "/items", ["78"])

    def add_item(self, item: str) -> None:
        items = self.items
        if item in items:
            index = items.index(item)
            items.pop(index)

        items.insert(0, item)

        self.__settings.setValue(
            self.__group + "/items", items[: self.max_size]
        )

    def clear(self) -> None:
        self.__settings.setValue(self.__group + "/items", [])

    @property
    def __group(self) -> str:
        return "NextGIS/RosreestrTools/search"
