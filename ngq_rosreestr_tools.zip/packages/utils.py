import os

from qgis.core import (
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface

from .pkk_feature_parser import PkkFeature


def add_to_new_layer(feature: PkkFeature) -> None:
    """Create layer and add feature to it"""
    # Choose name
    names = {
        1: "Земельные участки",
        2: "Кадастровые кварталы",
        4: "Кадастровые округа",
        5: "Объекты капитального строительства",
        10: "Зоны с особыми условиями использования территории",
    }
    name = names.get(feature.type_id, "Временный слой")

    # Create layer
    new_layer = QgsVectorLayer("MultiPolygon?crs=epsg:4326", name, "memory")
    data_provider = new_layer.dataProvider()
    assert data_provider is not None

    # Create fields
    fields = []
    for field in feature.fields:
        if field.name is None:
            continue
        qgis_field = QgsField(field.name, QVariant.Type.String)
        if field.alias is not None:
            qgis_field.setAlias(field.alias)
        fields.append(qgis_field)

        if field.can_have_formatted_value:
            qgis_field = QgsField(
                field.name + "_formatted", QVariant.Type.String
            )
            if field.alias is not None:
                qgis_field.setAlias(field.alias + " (с форматированием)")
            fields.append(qgis_field)

    data_provider.addAttributes(fields)
    new_layer.updateFields()

    # Load style
    styles = {
        1: "lands_polygons.qml",
        2: "blocks_polygons.qml",
        4: "subject_boundaries_polygons.qml",
        5: "builds_polygons.qml",
        10: "special_zones_polygons.qml",
    }
    if (style := styles.get(feature.type_id)) is not None:
        styles_path = os.path.join(
            os.path.dirname(__file__), os.pardir, "resources", "styles"
        )
        new_layer.loadNamedStyle(os.path.join(styles_path, style))

    new_feature = QgsFeature(new_layer.fields())
    new_feature.setGeometry(QgsGeometry(feature.geometry))
    for field in feature.fields:
        if field.name is None:
            continue
        current_index = data_provider.fieldNameIndex(field.name)
        if current_index == -1:
            continue
        new_feature.setAttribute(current_index, field.value)

        if field.formatted_value is not None:
            current_index = data_provider.fieldNameIndex(
                field.name + "_formatted"
            )
            if current_index == -1:
                continue
            new_feature.setAttribute(current_index, field.formatted_value)

    new_layer.startEditing()
    new_layer.addFeatures([new_feature])
    new_layer.commitChanges()

    project = QgsProject.instance()
    assert project is not None
    project.addMapLayer(new_layer, addToLegend=True)


def add_to_active_layer(feature: PkkFeature) -> None:
    active_layer = iface.mapCanvas().currentLayer()
    data_provider = active_layer.dataProvider()

    new_feature = QgsFeature(active_layer.fields())
    new_feature.setGeometry(QgsGeometry(feature.geometry))
    for field in feature.fields:
        if field.name is None:
            continue

        current_index = data_provider.fieldNameIndex(field.name)
        if current_index == -1:
            continue
        new_feature.setAttribute(current_index, field.value)

        if field.formatted_value is not None:
            current_index = data_provider.fieldNameIndex(
                field.name + "_formatted"
            )
            if current_index == -1:
                continue
            new_feature.setAttribute(current_index, field.formatted_value)

    active_layer.startEditing()
    active_layer.addFeatures([new_feature])
    active_layer.commitChanges()
