import os

from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsFileUtils,
)
from qgis.gui import QgsProjectionSelectionWidget
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QDir, Qt
from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QMessageBox,
)
from rosreestr_parser_task import RosreestrParserTask

from .egrn_tools_settings import EgrnToolsSettings

FORM_CLASS, _ = uic.loadUiType(
    os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.pardir,
            "resources",
            "import_egrn_ui.ui",
        )
    )
)

PLUGIN_DIR_NAME = "ngq_rosreestr_tools"


class NGQRosreestrToolsImportEGRN(QDialog, FORM_CLASS):
    plugin_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), os.pardir)
    )

    extensions_dict = {
        "GPKG": "gpkg",
        "GeoJSON": "geojson",
        "MapInfo File": "tab",
        "ESRI Shapefile": "shp",
    }

    def __init__(self, parent=None, plugin_password=None) -> None:
        # init dock
        super().__init__(parent)
        self.setupUi(self)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)

        self.progressBar.setVisible(False)

        self.get_ui_state()

        self.importEGRNSourceXMLPathBrowseButton.clicked.connect(
            self.browse_source
        )
        self.importEGRNOutputPathBrowseButton.clicked.connect(
            self.browse_output
        )

        self.importEGRNOutputFormatCombobox.currentIndexChanged.connect(
            self.data_format_changed
        )

        import_button = self.buttonBox.button(
            QDialogButtonBox.StandardButton.Open
        )
        import_button.setText("Импорт")
        import_button.clicked.connect(self.start_import)

        self.buttonBox.button(QDialogButtonBox.StandardButton.Close).setText(
            "Закрыть"
        )
        self.buttonBox.rejected.connect(self.close)

        # Настройка виджетов СК
        CrsOption = QgsProjectionSelectionWidget.CrsOption  # noqa: N806
        options_to_show = CrsOption.CrsNotSet
        self.sourceCrsWidget.setNotSetText("Подобрать автоматически")
        self.sourceCrsWidget.setOptionVisible(options_to_show, True)
        self.targetCrsWidget.setNotSetText("Не трансформировать")
        self.targetCrsWidget.setOptionVisible(options_to_show, True)

        if hasattr(CrsOption, "Invalid"):
            options_to_hide = CrsOption.Invalid
            self.sourceCrsWidget.setOptionVisible(options_to_hide, False)
            self.targetCrsWidget.setOptionVisible(options_to_hide, False)

    def reset(self) -> None:
        self.importEGRNSourceXMLPathLine.setText("")
        self.importEGRNOutputFormatCombobox.setCurrentIndex(0)
        self.importEGRNOutputPathLine.setText("")
        self.statusLabel.setText("")
        self.sourceCrsWidget.setCrs(QgsCoordinateReferenceSystem())
        self.targetCrsWidget.setCrs(QgsCoordinateReferenceSystem())

    def get_ui_state(self) -> None:
        settings = EgrnToolsSettings()

        self.importEGRNAddToProjectCheckbox.setChecked(
            settings.add_result_to_project
        )
        self.importEGRNIgnoreNoGeometriesCheckbox.setChecked(
            settings.skip_nogeom_features
        )
        self.importEGRNParseReestrExtractCheckbox.setChecked(
            settings.parse_extra_data
        )
        self.ignoreEmptyAttributesCheckbox.setChecked(
            settings.remove_empty_attributes
        )
        self.mergeUnrecognizedCheckBox.setChecked(settings.merge_unrecognized)

    def set_ui_state(self) -> None:
        settings = EgrnToolsSettings()

        settings.add_result_to_project = (
            self.importEGRNAddToProjectCheckbox.isChecked()
        )
        settings.skip_nogeom_features = (
            self.importEGRNIgnoreNoGeometriesCheckbox.isChecked()
        )
        settings.parse_extra_data = (
            self.importEGRNParseReestrExtractCheckbox.isChecked()
        )
        settings.remove_empty_attributes = (
            self.ignoreEmptyAttributesCheckbox.isChecked()
        )
        settings.merge_unrecognized = (
            self.mergeUnrecognizedCheckBox.isChecked()
        )

    def browse_source(self) -> None:
        input_basename = ""
        path_placeholder = ""

        line_edit_path = self.importEGRNSourceXMLPathLine.text()
        if len(line_edit_path) > 0:
            directory_path = os.path.dirname(line_edit_path)
            if os.path.exists(line_edit_path) and os.path.isfile(
                line_edit_path
            ):
                path_placeholder = line_edit_path
                input_basename = os.path.basename(path_placeholder)
                input_basename = os.path.splitext(input_basename)[0]
            elif os.path.exists(directory_path) and os.path.isdir(
                directory_path
            ):
                path_placeholder = directory_path

        if len(path_placeholder) == 0:
            settings = EgrnToolsSettings()
            path_placeholder = settings.last_source_dir
            if not os.path.exists(path_placeholder):
                path_placeholder = QDir.homePath()

        supported_filters = [
            "Файлы XML, ZIP (*.xml *.zip)",
            "Файлы XML (*.xml)",
            "Файлы ZIP (*.zip)",
        ]
        source_file = QFileDialog.getOpenFileName(
            self,
            directory=path_placeholder,
            filter=";;".join(supported_filters),
        )

        if not source_file[0]:
            return

        self.importEGRNSourceXMLPathLine.setText(source_file[0])

        # Update output if basename is same
        output_path = self.importEGRNOutputPathLine.text()
        output_dirname = os.path.dirname(output_path)
        if len(output_path) == 0:
            return

        output_basename = os.path.basename(output_path)
        output_basename, output_ext = os.path.splitext(output_basename)
        if input_basename != output_basename:
            return

        new_input_basename = os.path.basename(source_file[0])
        new_input_basename = os.path.splitext(new_input_basename)[0]

        self.importEGRNOutputPathLine.setText(
            f"{output_dirname}/{new_input_basename}{output_ext}"
        )

    def browse_output(self) -> None:
        path_placeholder = ""

        # Try to use current path
        line_edit_path = self.importEGRNOutputPathLine.text()
        if len(line_edit_path) > 0:
            directory_path = os.path.dirname(line_edit_path)
            if os.path.exists(directory_path) and os.path.isdir(
                directory_path
            ):
                path_placeholder = line_edit_path

        # If current is invalid use default
        if len(path_placeholder) == 0:
            settings = EgrnToolsSettings()
            path_placeholder = settings.last_destination_dir
            if not os.path.exists(path_placeholder):
                path_placeholder = QDir.homePath()

        # Get type filter
        data_format = self.importEGRNOutputFormatCombobox.currentText()
        extension = self.extensions_dict[data_format]

        # Try to use input file name
        source_path = self.importEGRNSourceXMLPathLine.text()
        if (
            os.path.isdir(path_placeholder)
            and len(source_path) > 0
            and os.path.exists(source_path)
            and os.path.isfile(source_path)
        ):
            base_name = os.path.basename(source_path)
            base_name_without_ext = os.path.splitext(base_name)[0]
            path_placeholder += f"/{base_name_without_ext}.{extension}"

        output_file = QFileDialog.getSaveFileName(
            self,
            directory=path_placeholder,
            filter=f"{data_format} (*.{extension})",
        )
        if output_file[0]:
            new_name = QgsFileUtils.ensureFileNameHasExtension(
                output_file[0], [extension]
            )
            self.importEGRNOutputPathLine.setText(new_name)

    def data_format_changed(self) -> None:
        output_file = self.importEGRNOutputPathLine.text()
        if output_file:
            output_file_dirname = os.path.dirname(output_file)
            output_file_basename = os.path.basename(output_file)
            output_file_basename_without_extension = ".".join(
                output_file_basename.split(".")[0:-1]
            )
            data_format = self.importEGRNOutputFormatCombobox.currentText()
            extension = self.extensions_dict[data_format]
            new_name = f"{output_file_dirname}/{output_file_basename_without_extension}.{extension}"

            self.importEGRNOutputPathLine.setText(new_name)

    def start_import(self) -> None:
        data_format = self.importEGRNOutputFormatCombobox.currentText()
        add_to_project = self.importEGRNAddToProjectCheckbox.isChecked()
        ignore_without_geom = (
            self.importEGRNIgnoreNoGeometriesCheckbox.isChecked()
        )
        parse_reestr_extract = (
            self.importEGRNParseReestrExtractCheckbox.isChecked()
        )
        remove_empty_attributes = (
            self.ignoreEmptyAttributesCheckbox.isChecked()
        )
        merge_unrecognized = self.mergeUnrecognizedCheckBox.isChecked()

        self.set_ui_state()

        source_file = self.importEGRNSourceXMLPathLine.text().strip()
        output_file = self.importEGRNOutputPathLine.text().strip()

        if source_file == "":
            QMessageBox.information(
                None, "Внимание!", "Не выбран исходный файл"
            )
            return

        source_crs_wkt = None
        source_crs_widget: QgsProjectionSelectionWidget = self.sourceCrsWidget
        source_crs = source_crs_widget.crs()
        if source_crs.isValid():
            source_crs_wkt = source_crs.toWkt()

        target_crs_wkt = None
        target_crs_widget: QgsProjectionSelectionWidget = self.targetCrsWidget
        target_crs = target_crs_widget.crs()
        if target_crs.isValid():
            target_crs_wkt = target_crs.toWkt()

        self.task = RosreestrParserTask(
            source_file,
            output_file,
            driver=data_format,
            source_crs=source_crs_wkt,
            target_crs=target_crs_wkt,
            parse_extra_data=parse_reestr_extract,
            ignore_without_geom=ignore_without_geom,
            remove_empty_attributes=remove_empty_attributes,
            add_to_project=add_to_project,
            open_dialog_slot=self.open,
            merge_not_recognized=merge_unrecognized,
        )
        QgsApplication.taskManager().addTask(self.task)
        self.close()
