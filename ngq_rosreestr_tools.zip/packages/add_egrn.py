import json
import os

from qgis.core import QgsProviderRegistry, QgsRasterLayer

allowed_types = ["kvartaly", "uchastki", "zony"]


def get_egrn_layer_params(ctype="kvartaly", api_key=None):
    endpoints_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), os.pardir, "resources", "endpoints.json"
        )
    )
    endpoints = None
    with open(endpoints_path) as f:
        endpoints = json.load(f)

    if ctype not in allowed_types:
        return {"status": "error", "message": "Неподдерживаемый тип слоя"}

    if api_key is None:
        return {"status": "error", "message": "Невозможно получить API KEY"}

    if ctype == "kvartaly":
        tms_url = endpoints["ng_tms_kvartaly_url"]
        layer_name = "Кадастровые кварталы, округа"
        # zmin = 3
        # zmax = 20
    elif ctype == "uchastki":
        tms_url = endpoints["ng_tms_uchastki_url"]
        layer_name = "Земельные участки, ОКС"
        # zmin = 15
        # zmax = 20
    elif ctype == "zony":
        tms_url = endpoints["ng_tms_zony_url"]
        layer_name = "Зоны с особыми условиями использования территории"
        # zmin = 10
        # zmax = 20
    else:
        return {"status": "error", "message": "Неподдерживаемый тип слоя"}

    provider_metadata = QgsProviderRegistry.instance().providerMetadata("wms")
    uri_params = {
        "type": "xyz",
        "url": f"{tms_url}?apikey={api_key}",
        "zmax": 20,
        "zmin": 3,
    }

    return {
        "status": "ok",
        "layer_name": layer_name,
        "uri": provider_metadata.encodeUri(uri_params),
    }


def get_egrn_layer(ctype="kvartaly", api_key=None):
    params = get_egrn_layer_params(ctype, api_key)
    if params["status"] != "ok":
        return params

    tms_layer = QgsRasterLayer(params["uri"], params["layer_name"], "wms")
    return {"status": "ok", "layer": tms_layer}
