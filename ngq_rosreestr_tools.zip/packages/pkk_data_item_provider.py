import os
from typing import List, Optional

from qgis._core import Qgis, QgsDataItem
from qgis.core import (
    QgsConnectionsRootItem,
    QgsDataItemProvider,
    QgsDataProvider,
    QgsErrorItem,
    QgsLayerItem,
)
from qgis.PyQt.QtGui import QIcon

from . import add_egrn, ng_network
from .egrn_tools_settings import EgrnToolsSettings

HAS_NGSTD = True
try:
    from ngstd._framework import NGAccess
except ImportError:
    HAS_NGSTD = False


class PkkLayerItem(QgsLayerItem):
    def __init__(
        self,
        parent: QgsDataItem,
        name: str,
        path: str,
        uri: str,
    ) -> None:
        super().__init__(
            parent, name, path, uri, Qgis.BrowserLayerType.Raster, "wms"
        )
        self.setIconName("mIconXyz.svg")
        self.setState(Qgis.BrowserItemState.Populated)


class PkkLayerRootItem(QgsConnectionsRootItem):
    def __init__(
        self,
        parent: QgsDataItem,
        name: str,
        path: str,
    ) -> None:
        super().__init__(parent, name, path, "WMS")

        current_path = os.path.abspath(os.path.dirname(__file__))
        icons_path = os.path.abspath(
            os.path.join(current_path, os.pardir, "resources", "icons")
        )
        icon_path = os.path.abspath(os.path.join(icons_path, "RR-raster.svg"))
        self.setIcon(QIcon(icon_path))

    def createChildren(self) -> List[QgsDataItem]:
        settings = EgrnToolsSettings()
        if not HAS_NGSTD and not settings.is_developer_mode:
            return [
                QgsErrorItem(
                    self,
                    "Отсутствует библиотека NGSTD",
                    f"{self.path()}/error",
                )
            ]

        if HAS_NGSTD and (
            not NGAccess.instance().isUserAuthorized()
            or not NGAccess.instance().isUserSupported()
        ):
            return [
                QgsErrorItem(
                    self,
                    "Невозможно получить ключ API",
                    f"{self.path()}/error",
                )
            ]

        api_key_request = ng_network.get_api_key()
        api_key = None
        if api_key_request["status"] == "ok":
            api_key = api_key_request["api_key"]
        if api_key is None:
            return [
                QgsErrorItem(
                    self,
                    "Невозможно получить ключ API",
                    f"{self.path()}/error",
                )
            ]

        children = []
        for layer_type in add_egrn.allowed_types:
            params = add_egrn.get_egrn_layer_params(layer_type, api_key)
            connection_name = params["layer_name"]
            item_path = f"{self.path()}/{connection_name}"
            layer_uri = params["uri"]
            child = PkkLayerItem(self, connection_name, item_path, layer_uri)
            children.append(child)

        return children


class PkkLayersDataItemProvider(QgsDataItemProvider):
    def name(self) -> str:
        return "NGQ Rosreestr Tools"

    def capabilities(self) -> int:
        return QgsDataProvider.DataCapability.Net

    def dataProviderKey(self) -> str:
        return "wms"

    def createDataItem(
        self, path: str, parentItem: Optional[QgsDataItem]
    ) -> Optional[QgsDataItem]:
        if len(path) > 0:
            return None

        item = PkkLayerRootItem(parentItem, self.name(), "pkk:")
        if HAS_NGSTD:
            NGAccess.instance().supportInfoUpdated.connect(item.refresh)
        return item
