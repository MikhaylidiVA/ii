from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsRectangle,
    QgsWkbTypes,
)
from qgis.gui import QgsRubberBand
from qgis.PyQt.QtGui import QColor
from qgis.utils import iface


class RubberBandResultRenderer:
    def __init__(self) -> None:
        self.iface = iface

        self.srs_wgs84 = QgsCoordinateReferenceSystem.fromEpsgId(4326)
        self.transformation = QgsCoordinateTransform(
            self.srs_wgs84, self.srs_wgs84, QgsProject.instance()
        )

        self.featureColor = QColor("green")

        self.rb = QgsRubberBand(
            self.iface.mapCanvas(), QgsWkbTypes.PolygonGeometry
        )
        self.rb.setColor(QColor(0, 176, 102, 200))
        self.rb.setIconSize(10)

        self.features_rb = QgsRubberBand(
            self.iface.mapCanvas(), QgsWkbTypes.PolygonGeometry
        )
        self.features_rb.setColor(self.featureColor)
        self.features_rb.setIconSize(12)
        self.features_rb.setWidth(3)

    def show_point(self, point, center=False) -> None:
        # check srs
        if self.need_transform():
            point = self.transform_point(point)

        self.rb.addPoint(point)
        if center:
            self.center_to_point(point)

    def clear(self) -> None:
        self.rb.reset(QgsWkbTypes.PointGeometry)

    def need_transform(self):
        return (
            self.iface.mapCanvas().mapSettings().destinationCrs().postgisSrid()
            != 4326
        )

    def transform_point(self, point):
        # dest_srs_id = self.iface.mapCanvas().mapSettings().destinationCrs().srsid()
        dest_srs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.transformation.setDestinationCrs(dest_srs)
        try:
            return self.transformation.transform(point)
        except Exception:
            print("Error on transform!")  # noqa: T201
            return None

    def transform_bbox(self, bbox):
        dest_srs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.transformation.setDestinationCrs(dest_srs)
        try:
            return self.transformation.transformBoundingBox(bbox)
        except Exception:
            print("Error on transform!")  # noqa: T201
            return None

    def transform_geom(self, geom):
        dest_srs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.transformation.setDestinationCrs(dest_srs)
        try:
            geom.transform(self.transformation)
        except Exception:  # Ловим только ожидаемые исключения
            print("Error on transform!")  # noqa: T201
            return None
        else:
            return geom

    def center_to_point(self, point) -> None:
        canvas = self.iface.mapCanvas()
        new_extent = QgsRectangle(canvas.extent())
        new_extent.scale(1, point)
        canvas.setExtent(new_extent)
        canvas.refresh()

    def zoom_to_bbox(self, bbox) -> None:
        if self.need_transform():
            bbox = self.transform_bbox(bbox)
        self.iface.mapCanvas().setExtent(bbox)
        self.iface.mapCanvas().refresh()

    def show_feature(self, geom, transform=False) -> None:
        if not transform:
            pass
        elif self.need_transform():
            geom = self.transform_geom(geom)

        if geom.type() == QgsWkbTypes.PointGeometry:
            self.features_rb.setFillColor(self.featureColor)
        else:
            self.features_rb.setFillColor(QColor(0, 176, 102, 200))

        self.features_rb.setToGeometry(geom, None)

    def clear_feature(self) -> None:
        self.features_rb.reset(QgsWkbTypes.PointGeometry)
