# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name  # noqa: ANN201
    """Load NGQRosreestrTools class from file NGQRosreestrTools

    :param iface: A QGIS interface instance.
    :type iface: QgisInterface
    """
    # pylint: disable=import-outside-toplevel
    from .ngq_rosreestr_tools import NGQRosreestrTools

    return NGQRosreestrTools(iface)
